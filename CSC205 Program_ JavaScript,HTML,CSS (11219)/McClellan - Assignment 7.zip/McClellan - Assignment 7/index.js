const adImage = document.getElementById('ad');
const images = ['ads/Dice_App.jpg', 'ads/Copilot.jpg', 'ads/NS+MW.jpg', 'ads/MC_Wiki.jpg'];
const randomIndex = Math.floor(Math.random() * images.length);

adImage.src = images[randomIndex];
