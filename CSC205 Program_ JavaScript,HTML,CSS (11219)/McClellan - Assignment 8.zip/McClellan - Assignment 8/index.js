let lastClick = "blank";
let count = 0;
let speed = 3000;
let intervalId = setInterval(changePic, speed);;

const images1 = [
    "img/BTD6Red.webp",
    "img/BTD6Blue.webp",
    "img/BTD6Green.webp",
    "img/BTD6Yellow.webp",
    "img/BTD6Pink.webp",
    "img/BTD6Black.webp",
    "img/BTD6White.webp",
    "img/BTD6Purple.webp",
    "img/BTD6Lead.webp",
    "img/BTD6Zebra.webp",
    "img/BTD6Ceramic.webp",
]

const images2 = [
    "img/BTD6_MOAB_Artwork.webp",
    "img/BTD6_BFB_Artwork.webp",
    "img/BTD6_ZOMG_Artwork.webp",
    "img/BTD6_DDT_Artwork.webp",
    "img/BTD6_BAD_Artwork.webp",
]
const images3 = [
    "img/QuincyPortrait.webp",
    "img/GwendolinPortrait.webp",
    "img/StrikerJonesPortrait.webp",
    "img/ObynGreenFootPortrait.webp",
    "img/RosaliaPortrait.webp",
    "img/CaptainChurchillPortrait.webp",
    "img/BenjaminPortrait.webp",
    "img/PatFustyPortrait.webp",
    "img/EziliPortrait.webp",
    "img/AdoraPortrait.webp",
    "img/EtiennePortrait.webp",
    "img/SaudaPortrait.webp",
    "img/AdmiralBrickellPortrait.webp",
    "img/PsiPortrait.webp",
    "img/GeraldoPortrait.webp",
    "img/CorvusPortrait.webp",
]

function func1(){
    lastClick = "1"
    changePic()
}

function func2(){
    lastClick = "2"    
    changePic()
}

function func3(){
    lastClick = "3"
    changePic()
}

function changePic(){
    let imgElement = document.getElementById("img");

    if (lastClick === "1") {
        if (count >= images1.length) count = 0;
        imgElement.src = images1[count];
    }

    if (lastClick === "2") {
        if (count >= images2.length) count = 0;
        imgElement.src = images2[count];
    }
    
    if (lastClick === "3") {
        if (count >= images3.length) count = 0;
        imgElement.src = images3[count];
    }
    
    if (lastClick === "blank") {
        imgElement.src = "img/blank.png";
        count = -1;
    }

    count++
}

function infinity(){
    if (confirm("This will cause some flashing. Do you want to continue?")) {
        speed = 0;
        changeSpeed();
    }
}

function speed4(){
    speed = 500;
    changeSpeed();
}

function speed3(){
    speed = 1000;
    changeSpeed();
}

function speed2(){
    speed = 2000;
    changeSpeed();
}

function speed1(){
    speed = 3000;
    changeSpeed();
}

function changeSpeed(){
    clearInterval(intervalId);
    intervalId = setInterval(changePic, speed);
}
