﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2_4_Flags
{
    public partial class Flag : Form
    {
        public Flag()
        {
            InitializeComponent();
        }

        private void canadaPictureBox_Click(object sender, EventArgs e)
        {
            countryLabel.Text = "Canada";
        }

        private void jpnPictureBox_Click(object sender, EventArgs e)
        {
            countryLabel.Text = "Japan";
        }

        private void piratePictureBox_Click(object sender, EventArgs e)
        {
            countryLabel.Text = "Pirate";
        }
    }
}
