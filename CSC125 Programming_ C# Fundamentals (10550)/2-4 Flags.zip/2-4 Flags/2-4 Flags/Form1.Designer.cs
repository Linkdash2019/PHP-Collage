﻿namespace _2_4_Flags
{
    partial class Flag
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Flag));
            this.instructionLabel = new System.Windows.Forms.Label();
            this.countryLabel = new System.Windows.Forms.Label();
            this.piratePictureBox = new System.Windows.Forms.PictureBox();
            this.jpnPictureBox = new System.Windows.Forms.PictureBox();
            this.canadaPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.piratePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jpnPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.canadaPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // instructionLabel
            // 
            this.instructionLabel.AutoSize = true;
            this.instructionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.instructionLabel.Location = new System.Drawing.Point(75, 22);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(255, 17);
            this.instructionLabel.TabIndex = 0;
            this.instructionLabel.Text = "Click a flag to see what type of flag it is.";
            // 
            // countryLabel
            // 
            this.countryLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.countryLabel.Location = new System.Drawing.Point(105, 189);
            this.countryLabel.Name = "countryLabel";
            this.countryLabel.Size = new System.Drawing.Size(206, 23);
            this.countryLabel.TabIndex = 4;
            this.countryLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // piratePictureBox
            // 
            this.piratePictureBox.BackColor = System.Drawing.Color.Black;
            this.piratePictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.piratePictureBox.Image = global::_2_4_Flags.Properties.Resources.pirate;
            this.piratePictureBox.Location = new System.Drawing.Point(286, 78);
            this.piratePictureBox.Name = "piratePictureBox";
            this.piratePictureBox.Size = new System.Drawing.Size(87, 47);
            this.piratePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.piratePictureBox.TabIndex = 3;
            this.piratePictureBox.TabStop = false;
            this.piratePictureBox.Click += new System.EventHandler(this.piratePictureBox_Click);
            // 
            // jpnPictureBox
            // 
            this.jpnPictureBox.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.jpnPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.jpnPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("jpnPictureBox.Image")));
            this.jpnPictureBox.Location = new System.Drawing.Point(162, 78);
            this.jpnPictureBox.Name = "jpnPictureBox";
            this.jpnPictureBox.Size = new System.Drawing.Size(82, 47);
            this.jpnPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.jpnPictureBox.TabIndex = 2;
            this.jpnPictureBox.TabStop = false;
            this.jpnPictureBox.Click += new System.EventHandler(this.jpnPictureBox_Click);
            // 
            // canadaPictureBox
            // 
            this.canadaPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.canadaPictureBox.Image = global::_2_4_Flags.Properties.Resources.canada;
            this.canadaPictureBox.Location = new System.Drawing.Point(32, 78);
            this.canadaPictureBox.Name = "canadaPictureBox";
            this.canadaPictureBox.Size = new System.Drawing.Size(87, 47);
            this.canadaPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.canadaPictureBox.TabIndex = 1;
            this.canadaPictureBox.TabStop = false;
            this.canadaPictureBox.Click += new System.EventHandler(this.canadaPictureBox_Click);
            // 
            // Flag
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(413, 245);
            this.Controls.Add(this.countryLabel);
            this.Controls.Add(this.piratePictureBox);
            this.Controls.Add(this.jpnPictureBox);
            this.Controls.Add(this.canadaPictureBox);
            this.Controls.Add(this.instructionLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Flag";
            this.Text = "Flag";
            ((System.ComponentModel.ISupportInitialize)(this.piratePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jpnPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.canadaPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.PictureBox canadaPictureBox;
        private System.Windows.Forms.PictureBox jpnPictureBox;
        private System.Windows.Forms.PictureBox piratePictureBox;
        private System.Windows.Forms.Label countryLabel;
    }
}

