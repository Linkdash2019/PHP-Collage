﻿namespace _3_5_Change_Counter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._5CentsPictureBox = new System.Windows.Forms.PictureBox();
            this._10CentsPictureBox = new System.Windows.Forms.PictureBox();
            this._25CentsPictureBox = new System.Windows.Forms.PictureBox();
            this._50CentsPictureBox = new System.Windows.Forms.PictureBox();
            this.outputDescriptionLabel = new System.Windows.Forms.Label();
            this.totalCounter = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this._5CentsPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._10CentsPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._25CentsPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._50CentsPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // _5CentsPictureBox
            // 
            this._5CentsPictureBox.Image = global::_3_5_Change_Counter.Properties.Resources._5cents;
            this._5CentsPictureBox.Location = new System.Drawing.Point(12, 12);
            this._5CentsPictureBox.Name = "_5CentsPictureBox";
            this._5CentsPictureBox.Size = new System.Drawing.Size(125, 181);
            this._5CentsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this._5CentsPictureBox.TabIndex = 0;
            this._5CentsPictureBox.TabStop = false;
            this._5CentsPictureBox.Click += new System.EventHandler(this._5CentsPictureBox_Click);
            // 
            // _10CentsPictureBox
            // 
            this._10CentsPictureBox.Image = global::_3_5_Change_Counter.Properties.Resources._10cents;
            this._10CentsPictureBox.Location = new System.Drawing.Point(156, 12);
            this._10CentsPictureBox.Name = "_10CentsPictureBox";
            this._10CentsPictureBox.Size = new System.Drawing.Size(125, 181);
            this._10CentsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this._10CentsPictureBox.TabIndex = 1;
            this._10CentsPictureBox.TabStop = false;
            this._10CentsPictureBox.Click += new System.EventHandler(this._10CentsPictureBox_Click);
            // 
            // _25CentsPictureBox
            // 
            this._25CentsPictureBox.Image = global::_3_5_Change_Counter.Properties.Resources._25cents;
            this._25CentsPictureBox.Location = new System.Drawing.Point(12, 212);
            this._25CentsPictureBox.Name = "_25CentsPictureBox";
            this._25CentsPictureBox.Size = new System.Drawing.Size(125, 181);
            this._25CentsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this._25CentsPictureBox.TabIndex = 2;
            this._25CentsPictureBox.TabStop = false;
            this._25CentsPictureBox.Click += new System.EventHandler(this._25CentsPictureBox_Click);
            // 
            // _50CentsPictureBox
            // 
            this._50CentsPictureBox.Image = global::_3_5_Change_Counter.Properties.Resources._50cents;
            this._50CentsPictureBox.Location = new System.Drawing.Point(156, 212);
            this._50CentsPictureBox.Name = "_50CentsPictureBox";
            this._50CentsPictureBox.Size = new System.Drawing.Size(125, 181);
            this._50CentsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this._50CentsPictureBox.TabIndex = 3;
            this._50CentsPictureBox.TabStop = false;
            this._50CentsPictureBox.Click += new System.EventHandler(this._50CentsPictureBox_Click);
            // 
            // outputDescriptionLabel
            // 
            this.outputDescriptionLabel.AutoSize = true;
            this.outputDescriptionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.outputDescriptionLabel.Location = new System.Drawing.Point(342, 186);
            this.outputDescriptionLabel.Name = "outputDescriptionLabel";
            this.outputDescriptionLabel.Size = new System.Drawing.Size(40, 17);
            this.outputDescriptionLabel.TabIndex = 4;
            this.outputDescriptionLabel.Text = "Total";
            // 
            // totalCounter
            // 
            this.totalCounter.AutoSize = true;
            this.totalCounter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalCounter.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.totalCounter.Location = new System.Drawing.Point(334, 212);
            this.totalCounter.Name = "totalCounter";
            this.totalCounter.Size = new System.Drawing.Size(57, 24);
            this.totalCounter.TabIndex = 5;
            this.totalCounter.Text = "$0.00";
            this.totalCounter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(186, 421);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(430, 468);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.totalCounter);
            this.Controls.Add(this.outputDescriptionLabel);
            this.Controls.Add(this._50CentsPictureBox);
            this.Controls.Add(this._25CentsPictureBox);
            this.Controls.Add(this._10CentsPictureBox);
            this.Controls.Add(this._5CentsPictureBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Change Counter";
            ((System.ComponentModel.ISupportInitialize)(this._5CentsPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._10CentsPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._25CentsPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._50CentsPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox _5CentsPictureBox;
        private System.Windows.Forms.PictureBox _10CentsPictureBox;
        private System.Windows.Forms.PictureBox _25CentsPictureBox;
        private System.Windows.Forms.PictureBox _50CentsPictureBox;
        private System.Windows.Forms.Label outputDescriptionLabel;
        private System.Windows.Forms.Label totalCounter;
        private System.Windows.Forms.Button exitButton;
    }
}

