﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3_5_Change_Counter
{
    public partial class Form1 : Form
    {
        double totalCents = 0;
        const double FIVE_CENTS_VALUE = 0.05;
        const double TEN_CENTS_VALUE = 0.10;
        const double TWENTY_FIVE_CENTS_VALUE = 0.25;
        const double FIFTY_CENTS_VALUE = 0.50;

        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void _5CentsPictureBox_Click(object sender, EventArgs e)
        {
            totalCents += FIVE_CENTS_VALUE;
            totalCounter.Text = totalCents.ToString("c");
        }

        private void _10CentsPictureBox_Click(object sender, EventArgs e)
        {
            totalCents += TEN_CENTS_VALUE;
            totalCounter.Text = totalCents.ToString("c");
        }

        private void _25CentsPictureBox_Click(object sender, EventArgs e)
        {
            totalCents += TWENTY_FIVE_CENTS_VALUE;
            totalCounter.Text = totalCents.ToString("c");
        }

        private void _50CentsPictureBox_Click(object sender, EventArgs e)
        {
            totalCents += FIFTY_CENTS_VALUE;
            totalCounter.Text = totalCents.ToString("c");
        }
    }
}
