﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_7_10
{
    public partial class Form1 : Form
    {
        int tokens = 100;

        public Form1()
        {
            InitializeComponent();   
        }

        private async void startButton_Click(object sender, EventArgs e)
        {
            //Get variables set up and do error checking
            if (int.TryParse(betTextBox.Text, out int bet))
            {
                tokens -= bet;
            }
            else
            {
                MessageBox.Show("Invalid input");
                goto exit; 
            }

            if (tokens < 0)
            {
                tokens += bet;
                MessageBox.Show("Invalid input");
                goto exit;
            }
            else
            {
                tokenLabel.Text = tokens.ToString();
                Random rand = new Random();
                int slot1 = 1;
                int slot2 = 1;
                int slot3 = 1;
                int index = 0;

                startButton.Enabled = false;

                //Animation loop
                while (index != 20)
                {
                    //image 1
                    slot1 = rand.Next(fruitList.Images.Count);
                    pictureBox1.Image = fruitList.Images[slot1];

                    //image 2
                    slot2 = rand.Next(fruitList.Images.Count);
                    pictureBox2.Image = fruitList.Images[slot2];

                    //image 3
                    slot3 = rand.Next(fruitList.Images.Count);
                    pictureBox3.Image = fruitList.Images[slot3];

                    await Task.Delay(100);
                    index++;
                }

                //determine results
                if (slot1 == slot2 || slot1 == slot3 || slot2 == slot3)
                {
                    if (slot1 == slot2 && slot2 == slot3)
                    {
                        tokens += bet * 3;
                        MessageBox.Show("JACKPOT\nYou earned " + bet*3 + " Tokens!\nYou have " + tokens + " tokens.");
                    }
                    else
                    {
                        tokens += bet * 2;
                        MessageBox.Show("2 Match!\nYou earned " + bet*2 + " Tokens!\nYou have " + tokens + " tokens.");
                    }
                }
                else
                {
                    MessageBox.Show("No matches\nNo tokens earned.\nYou have " + tokens + " tokens.");
                }
            }
            // \/ that down there
            exit:;
            tokenLabel.Text = tokens.ToString();
            if (tokens != 0)
            {
                startButton.Enabled = true;
            }
            else
            {
                //Prevent gameplay if the user is out of tokens
                betTextBox.Enabled = false;
                MessageBox.Show("Your out of tokens!");
            }     
        }
    }
}
