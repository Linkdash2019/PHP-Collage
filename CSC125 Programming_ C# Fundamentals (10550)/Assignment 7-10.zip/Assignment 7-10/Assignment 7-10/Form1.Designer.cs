﻿namespace Assignment_7_10
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.fruitList = new System.Windows.Forms.ImageList(this.components);
            this.startButton = new System.Windows.Forms.Button();
            this.tokenDescLabel = new System.Windows.Forms.Label();
            this.tokenLabel = new System.Windows.Forms.Label();
            this.betTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Assignment_7_10.Properties.Resources.Orange;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Assignment_7_10.Properties.Resources.Grapes;
            this.pictureBox2.Location = new System.Drawing.Point(146, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(128, 128);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Assignment_7_10.Properties.Resources.Cherries;
            this.pictureBox3.Location = new System.Drawing.Point(281, 12);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(128, 128);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // fruitList
            // 
            this.fruitList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("fruitList.ImageStream")));
            this.fruitList.TransparentColor = System.Drawing.Color.Transparent;
            this.fruitList.Images.SetKeyName(0, "Apple.bmp");
            this.fruitList.Images.SetKeyName(1, "Banana.bmp");
            this.fruitList.Images.SetKeyName(2, "Cherries.bmp");
            this.fruitList.Images.SetKeyName(3, "Grapes.bmp");
            this.fruitList.Images.SetKeyName(4, "Lemon.bmp");
            this.fruitList.Images.SetKeyName(5, "Lime.bmp");
            this.fruitList.Images.SetKeyName(6, "Orange.bmp");
            this.fruitList.Images.SetKeyName(7, "Pear.bmp");
            this.fruitList.Images.SetKeyName(8, "Strawberry.bmp");
            this.fruitList.Images.SetKeyName(9, "Watermelon.bmp");
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(146, 223);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(128, 23);
            this.startButton.TabIndex = 3;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // tokenDescLabel
            // 
            this.tokenDescLabel.AutoSize = true;
            this.tokenDescLabel.Location = new System.Drawing.Point(86, 154);
            this.tokenDescLabel.Name = "tokenDescLabel";
            this.tokenDescLabel.Size = new System.Drawing.Size(107, 13);
            this.tokenDescLabel.TabIndex = 4;
            this.tokenDescLabel.Text = "Total Owned Tokens";
            // 
            // tokenLabel
            // 
            this.tokenLabel.BackColor = System.Drawing.Color.White;
            this.tokenLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tokenLabel.Location = new System.Drawing.Point(100, 172);
            this.tokenLabel.Name = "tokenLabel";
            this.tokenLabel.Size = new System.Drawing.Size(79, 14);
            this.tokenLabel.TabIndex = 5;
            this.tokenLabel.Text = "100";
            this.tokenLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // betTextBox
            // 
            this.betTextBox.Location = new System.Drawing.Point(234, 172);
            this.betTextBox.MaxLength = 5;
            this.betTextBox.Name = "betTextBox";
            this.betTextBox.Size = new System.Drawing.Size(79, 20);
            this.betTextBox.TabIndex = 6;
            this.betTextBox.Text = "1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(236, 154);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Tokens to Bet";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 258);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.betTextBox);
            this.Controls.Add(this.tokenLabel);
            this.Controls.Add(this.tokenDescLabel);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Slot Machine Simulator";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.ImageList fruitList;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Label tokenDescLabel;
        private System.Windows.Forms.Label tokenLabel;
        private System.Windows.Forms.TextBox betTextBox;
        private System.Windows.Forms.Label label1;
    }
}

