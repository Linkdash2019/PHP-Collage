﻿namespace Random_Card
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.getCardButton = new System.Windows.Forms.Button();
            this.cardPictureBox = new System.Windows.Forms.PictureBox();
            this.cardImageList = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.cardPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // getCardButton
            // 
            this.getCardButton.Location = new System.Drawing.Point(87, 102);
            this.getCardButton.Name = "getCardButton";
            this.getCardButton.Size = new System.Drawing.Size(75, 36);
            this.getCardButton.TabIndex = 3;
            this.getCardButton.Text = "Get Random Card";
            this.getCardButton.UseVisualStyleBackColor = true;
            this.getCardButton.Click += new System.EventHandler(this.getCardButton_Click);
            // 
            // cardPictureBox
            // 
            this.cardPictureBox.Image = global::Random_Card.Properties.Resources.Backface_Blue;
            this.cardPictureBox.Location = new System.Drawing.Point(99, 13);
            this.cardPictureBox.Name = "cardPictureBox";
            this.cardPictureBox.Size = new System.Drawing.Size(50, 70);
            this.cardPictureBox.TabIndex = 2;
            this.cardPictureBox.TabStop = false;
            // 
            // cardImageList
            // 
            this.cardImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("cardImageList.ImageStream")));
            this.cardImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.cardImageList.Images.SetKeyName(0, "King_Clubs.bmp");
            this.cardImageList.Images.SetKeyName(1, "King_Diamonds.bmp");
            this.cardImageList.Images.SetKeyName(2, "King_Hearts.bmp");
            this.cardImageList.Images.SetKeyName(3, "King_Spades.bmp");
            this.cardImageList.Images.SetKeyName(4, "Queen_Clubs.bmp");
            this.cardImageList.Images.SetKeyName(5, "Queen_Diamonds.bmp");
            this.cardImageList.Images.SetKeyName(6, "Queen_Hearts.bmp");
            this.cardImageList.Images.SetKeyName(7, "Queen_Spades.bmp");
            this.cardImageList.Images.SetKeyName(8, "2_Clubs.bmp");
            this.cardImageList.Images.SetKeyName(9, "2_Diamonds.bmp");
            this.cardImageList.Images.SetKeyName(10, "2_Hearts.bmp");
            this.cardImageList.Images.SetKeyName(11, "2_Spades.bmp");
            this.cardImageList.Images.SetKeyName(12, "3_Clubs.bmp");
            this.cardImageList.Images.SetKeyName(13, "3_Diamonds.bmp");
            this.cardImageList.Images.SetKeyName(14, "3_Hearts.bmp");
            this.cardImageList.Images.SetKeyName(15, "3_Spades.bmp");
            this.cardImageList.Images.SetKeyName(16, "4_Clubs.bmp");
            this.cardImageList.Images.SetKeyName(17, "4_Diamonds.bmp");
            this.cardImageList.Images.SetKeyName(18, "4_Hearts.bmp");
            this.cardImageList.Images.SetKeyName(19, "4_Spades.bmp");
            this.cardImageList.Images.SetKeyName(20, "5_Clubs.bmp");
            this.cardImageList.Images.SetKeyName(21, "5_Diamonds.bmp");
            this.cardImageList.Images.SetKeyName(22, "5_Hearts.bmp");
            this.cardImageList.Images.SetKeyName(23, "5_Spades.bmp");
            this.cardImageList.Images.SetKeyName(24, "6_Clubs.bmp");
            this.cardImageList.Images.SetKeyName(25, "6_Diamonds.bmp");
            this.cardImageList.Images.SetKeyName(26, "6_Hearts.bmp");
            this.cardImageList.Images.SetKeyName(27, "6_Spades.bmp");
            this.cardImageList.Images.SetKeyName(28, "7_Clubs.bmp");
            this.cardImageList.Images.SetKeyName(29, "7_Diamonds.bmp");
            this.cardImageList.Images.SetKeyName(30, "7_Hearts.bmp");
            this.cardImageList.Images.SetKeyName(31, "7_Spades.bmp");
            this.cardImageList.Images.SetKeyName(32, "8_Clubs.bmp");
            this.cardImageList.Images.SetKeyName(33, "8_Diamonds.bmp");
            this.cardImageList.Images.SetKeyName(34, "8_Hearts.bmp");
            this.cardImageList.Images.SetKeyName(35, "8_Spades.bmp");
            this.cardImageList.Images.SetKeyName(36, "9_Clubs.bmp");
            this.cardImageList.Images.SetKeyName(37, "9_Diamonds.bmp");
            this.cardImageList.Images.SetKeyName(38, "9_Hearts.bmp");
            this.cardImageList.Images.SetKeyName(39, "9_Spades.bmp");
            this.cardImageList.Images.SetKeyName(40, "10_Clubs.bmp");
            this.cardImageList.Images.SetKeyName(41, "10_Diamonds.bmp");
            this.cardImageList.Images.SetKeyName(42, "10_Hearts.bmp");
            this.cardImageList.Images.SetKeyName(43, "10_Spades.bmp");
            this.cardImageList.Images.SetKeyName(44, "Ace_Clubs.bmp");
            this.cardImageList.Images.SetKeyName(45, "Ace_Diamonds.bmp");
            this.cardImageList.Images.SetKeyName(46, "Ace_Hearts.bmp");
            this.cardImageList.Images.SetKeyName(47, "Ace_Spades.bmp");
            this.cardImageList.Images.SetKeyName(48, "Jack_Clubs.bmp");
            this.cardImageList.Images.SetKeyName(49, "Jack_Diamonds.bmp");
            this.cardImageList.Images.SetKeyName(50, "Jack_Hearts.bmp");
            this.cardImageList.Images.SetKeyName(51, "Jack_Spades.bmp");
            this.cardImageList.Images.SetKeyName(52, "Joker_Black.bmp");
            this.cardImageList.Images.SetKeyName(53, "Joker_Red.bmp");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(249, 150);
            this.Controls.Add(this.getCardButton);
            this.Controls.Add(this.cardPictureBox);
            this.Name = "Form1";
            this.Text = "Random Card";
            ((System.ComponentModel.ISupportInitialize)(this.cardPictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button getCardButton;
        private System.Windows.Forms.PictureBox cardPictureBox;
        private System.Windows.Forms.ImageList cardImageList;
    }
}

