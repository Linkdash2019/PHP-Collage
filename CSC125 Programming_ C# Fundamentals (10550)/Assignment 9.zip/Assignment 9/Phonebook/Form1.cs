﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Phonebook
{
    struct Encoder
    {
       public string orgin;
        public string after;
    }

    public partial class Form1 : Form
    {
        private List<Encoder> encoder = new List<Encoder>();
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            readFile();
        }

        private void readFile()
        {
            try
            {
                StreamReader inputFile;
                string line;
                Encoder entry = new Encoder();
                char[] delim = { ',' };
                inputFile = File.OpenText("PhoneList.txt");
                while (!inputFile.EndOfStream)
                {
                    line = inputFile.ReadLine();
                    string[] tokens = line.Split(delim);
                    entry.orgin = tokens[0];
                    entry.after = tokens[1];
                    encoder.Add(entry);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void decodeButton_Click(object sender, EventArgs e)
        {
            if (encodeTextBox.Text == "")
            {
                MessageBox.Show("Please enter a string to decode.");
                return;
            }
            decodeTextBox.Text = "";
            char[] encode_char_array = encodeTextBox.Text.ToCharArray();
            foreach (char c in encode_char_array)
            {
                foreach (Encoder entry in encoder)
                {
                    if (c.ToString() == entry.after)
                    {
                        decodeTextBox.Text += entry.orgin;
                    }
                }
            }
            encodeTextBox.Text = "";
        }

        private void encodeButton_Click(object sender, EventArgs e)
        {
            if (decodeTextBox.Text == "")
            {
                MessageBox.Show("Please enter a string to encode.");
                return;
            }
            encodeTextBox.Text = "";
            char[] decode_char_array = decodeTextBox.Text.ToCharArray();
            foreach (char c in decode_char_array)
            {
                foreach (Encoder entry in encoder)
                {
                    if (c.ToString() == entry.orgin)
                    {
                        encodeTextBox.Text += entry.after;
                    }
                }
            }
            decodeTextBox.Text = "";
        }
    }
}
