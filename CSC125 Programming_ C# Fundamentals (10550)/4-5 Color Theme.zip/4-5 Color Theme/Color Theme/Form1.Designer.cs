﻿namespace Color_Theme
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.redButton = new System.Windows.Forms.RadioButton();
            this.blueButton = new System.Windows.Forms.RadioButton();
            this.purpleButton = new System.Windows.Forms.RadioButton();
            this.whiteButton = new System.Windows.Forms.RadioButton();
            this.colorBox = new System.Windows.Forms.GroupBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.colorBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // redButton
            // 
            this.redButton.AutoSize = true;
            this.redButton.Location = new System.Drawing.Point(54, 19);
            this.redButton.Name = "redButton";
            this.redButton.Size = new System.Drawing.Size(45, 17);
            this.redButton.TabIndex = 1;
            this.redButton.Text = "Red";
            this.redButton.UseVisualStyleBackColor = true;
            this.redButton.CheckedChanged += new System.EventHandler(this.redButton_CheckedChanged);
            // 
            // blueButton
            // 
            this.blueButton.AutoSize = true;
            this.blueButton.Location = new System.Drawing.Point(54, 43);
            this.blueButton.Name = "blueButton";
            this.blueButton.Size = new System.Drawing.Size(46, 17);
            this.blueButton.TabIndex = 2;
            this.blueButton.Text = "Blue";
            this.blueButton.UseVisualStyleBackColor = true;
            this.blueButton.CheckedChanged += new System.EventHandler(this.blueButton_CheckedChanged);
            // 
            // purpleButton
            // 
            this.purpleButton.AutoSize = true;
            this.purpleButton.Location = new System.Drawing.Point(54, 67);
            this.purpleButton.Name = "purpleButton";
            this.purpleButton.Size = new System.Drawing.Size(55, 17);
            this.purpleButton.TabIndex = 3;
            this.purpleButton.Text = "Purple";
            this.purpleButton.UseVisualStyleBackColor = true;
            this.purpleButton.CheckedChanged += new System.EventHandler(this.purpleButton_CheckedChanged);
            // 
            // whiteButton
            // 
            this.whiteButton.AutoSize = true;
            this.whiteButton.Checked = true;
            this.whiteButton.Location = new System.Drawing.Point(54, 91);
            this.whiteButton.Name = "whiteButton";
            this.whiteButton.Size = new System.Drawing.Size(96, 17);
            this.whiteButton.TabIndex = 0;
            this.whiteButton.TabStop = true;
            this.whiteButton.Text = "White (Default)";
            this.whiteButton.UseVisualStyleBackColor = true;
            this.whiteButton.CheckedChanged += new System.EventHandler(this.whiteButton_CheckedChanged);
            // 
            // colorBox
            // 
            this.colorBox.Controls.Add(this.redButton);
            this.colorBox.Controls.Add(this.whiteButton);
            this.colorBox.Controls.Add(this.blueButton);
            this.colorBox.Controls.Add(this.purpleButton);
            this.colorBox.Location = new System.Drawing.Point(12, 12);
            this.colorBox.Name = "colorBox";
            this.colorBox.Size = new System.Drawing.Size(200, 130);
            this.colorBox.TabIndex = 4;
            this.colorBox.TabStop = false;
            this.colorBox.Text = "Select a backround color";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(66, 168);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(221, 203);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.colorBox);
            this.Name = "Form1";
            this.Text = "Color Theme";
            this.colorBox.ResumeLayout(false);
            this.colorBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RadioButton redButton;
        private System.Windows.Forms.RadioButton blueButton;
        private System.Windows.Forms.RadioButton purpleButton;
        private System.Windows.Forms.RadioButton whiteButton;
        private System.Windows.Forms.GroupBox colorBox;
        private System.Windows.Forms.Button exitButton;
    }
}

