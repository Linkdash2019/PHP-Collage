﻿namespace Assignment_3_12
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.paintGallonDescLabel = new System.Windows.Forms.Label();
            this.paintGallonLabel = new System.Windows.Forms.Label();
            this.hoursLabel = new System.Windows.Forms.Label();
            this.workHoursDescLabel = new System.Windows.Forms.Label();
            this.paintCostLabel = new System.Windows.Forms.Label();
            this.paintCostDescLabel = new System.Windows.Forms.Label();
            this.laborCostLabel = new System.Windows.Forms.Label();
            this.laborCostDescLabel = new System.Windows.Forms.Label();
            this.totalCostLabel = new System.Windows.Forms.Label();
            this.totalCostDescLabel = new System.Windows.Forms.Label();
            this.caculateButton = new System.Windows.Forms.Button();
            this.wallSpaceTextBox = new System.Windows.Forms.TextBox();
            this._1GalPaintCostTextBox = new System.Windows.Forms.TextBox();
            this.wallSpaceLabel = new System.Windows.Forms.Label();
            this._1GalPaintCostDescLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // paintGallonDescLabel
            // 
            this.paintGallonDescLabel.AutoSize = true;
            this.paintGallonDescLabel.Location = new System.Drawing.Point(344, 210);
            this.paintGallonDescLabel.Name = "paintGallonDescLabel";
            this.paintGallonDescLabel.Size = new System.Drawing.Size(127, 13);
            this.paintGallonDescLabel.TabIndex = 0;
            this.paintGallonDescLabel.Text = "Gallons of Paint Required";
            // 
            // paintGallonLabel
            // 
            this.paintGallonLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.paintGallonLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.paintGallonLabel.Location = new System.Drawing.Point(355, 237);
            this.paintGallonLabel.Name = "paintGallonLabel";
            this.paintGallonLabel.Size = new System.Drawing.Size(104, 26);
            this.paintGallonLabel.TabIndex = 1;
            this.paintGallonLabel.Text = "0 Gallon(s)";
            this.paintGallonLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // hoursLabel
            // 
            this.hoursLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.hoursLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.hoursLabel.Location = new System.Drawing.Point(65, 237);
            this.hoursLabel.Name = "hoursLabel";
            this.hoursLabel.Size = new System.Drawing.Size(104, 26);
            this.hoursLabel.TabIndex = 3;
            this.hoursLabel.Text = "0 Hour(s)";
            this.hoursLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // workHoursDescLabel
            // 
            this.workHoursDescLabel.AutoSize = true;
            this.workHoursDescLabel.Location = new System.Drawing.Point(61, 209);
            this.workHoursDescLabel.Name = "workHoursDescLabel";
            this.workHoursDescLabel.Size = new System.Drawing.Size(110, 13);
            this.workHoursDescLabel.TabIndex = 2;
            this.workHoursDescLabel.Text = "Work Hours Required";
            // 
            // paintCostLabel
            // 
            this.paintCostLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.paintCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.paintCostLabel.Location = new System.Drawing.Point(495, 237);
            this.paintCostLabel.Name = "paintCostLabel";
            this.paintCostLabel.Size = new System.Drawing.Size(104, 26);
            this.paintCostLabel.TabIndex = 5;
            this.paintCostLabel.Text = "$0.00";
            this.paintCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // paintCostDescLabel
            // 
            this.paintCostDescLabel.AutoSize = true;
            this.paintCostDescLabel.Location = new System.Drawing.Point(520, 209);
            this.paintCostDescLabel.Name = "paintCostDescLabel";
            this.paintCostDescLabel.Size = new System.Drawing.Size(55, 13);
            this.paintCostDescLabel.TabIndex = 4;
            this.paintCostDescLabel.Text = "Paint Cost";
            // 
            // laborCostLabel
            // 
            this.laborCostLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.laborCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.laborCostLabel.Location = new System.Drawing.Point(207, 237);
            this.laborCostLabel.Name = "laborCostLabel";
            this.laborCostLabel.Size = new System.Drawing.Size(104, 26);
            this.laborCostLabel.TabIndex = 7;
            this.laborCostLabel.Text = "$0.00";
            this.laborCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // laborCostDescLabel
            // 
            this.laborCostDescLabel.AutoSize = true;
            this.laborCostDescLabel.Location = new System.Drawing.Point(231, 209);
            this.laborCostDescLabel.Name = "laborCostDescLabel";
            this.laborCostDescLabel.Size = new System.Drawing.Size(63, 13);
            this.laborCostDescLabel.TabIndex = 6;
            this.laborCostDescLabel.Text = "Labor Costs";
            // 
            // totalCostLabel
            // 
            this.totalCostLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalCostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.totalCostLabel.Location = new System.Drawing.Point(623, 237);
            this.totalCostLabel.Name = "totalCostLabel";
            this.totalCostLabel.Size = new System.Drawing.Size(104, 26);
            this.totalCostLabel.TabIndex = 9;
            this.totalCostLabel.Text = "$0.00";
            this.totalCostLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalCostDescLabel
            // 
            this.totalCostDescLabel.AutoSize = true;
            this.totalCostDescLabel.Location = new System.Drawing.Point(652, 209);
            this.totalCostDescLabel.Name = "totalCostDescLabel";
            this.totalCostDescLabel.Size = new System.Drawing.Size(53, 13);
            this.totalCostDescLabel.TabIndex = 8;
            this.totalCostDescLabel.Text = "Final Cost";
            // 
            // caculateButton
            // 
            this.caculateButton.Location = new System.Drawing.Point(349, 130);
            this.caculateButton.Name = "caculateButton";
            this.caculateButton.Size = new System.Drawing.Size(104, 41);
            this.caculateButton.TabIndex = 10;
            this.caculateButton.Text = "Caculate";
            this.caculateButton.UseVisualStyleBackColor = true;
            this.caculateButton.Click += new System.EventHandler(this.caculateButton_Click);
            // 
            // wallSpaceTextBox
            // 
            this.wallSpaceTextBox.BackColor = System.Drawing.Color.White;
            this.wallSpaceTextBox.Location = new System.Drawing.Point(209, 102);
            this.wallSpaceTextBox.Name = "wallSpaceTextBox";
            this.wallSpaceTextBox.Size = new System.Drawing.Size(100, 20);
            this.wallSpaceTextBox.TabIndex = 11;
            // 
            // _1GalPaintCostTextBox
            // 
            this._1GalPaintCostTextBox.BackColor = System.Drawing.Color.White;
            this._1GalPaintCostTextBox.Location = new System.Drawing.Point(489, 102);
            this._1GalPaintCostTextBox.Name = "_1GalPaintCostTextBox";
            this._1GalPaintCostTextBox.Size = new System.Drawing.Size(100, 20);
            this._1GalPaintCostTextBox.TabIndex = 12;
            // 
            // wallSpaceLabel
            // 
            this.wallSpaceLabel.AutoSize = true;
            this.wallSpaceLabel.Location = new System.Drawing.Point(204, 80);
            this.wallSpaceLabel.Name = "wallSpaceLabel";
            this.wallSpaceLabel.Size = new System.Drawing.Size(114, 13);
            this.wallSpaceLabel.TabIndex = 13;
            this.wallSpaceLabel.Text = "Square Ft. Wall Space";
            // 
            // _1GalPaintCostDescLabel
            // 
            this._1GalPaintCostDescLabel.AutoSize = true;
            this._1GalPaintCostDescLabel.Location = new System.Drawing.Point(478, 80);
            this._1GalPaintCostDescLabel.Name = "_1GalPaintCostDescLabel";
            this._1GalPaintCostDescLabel.Size = new System.Drawing.Size(121, 13);
            this._1GalPaintCostDescLabel.TabIndex = 14;
            this._1GalPaintCostDescLabel.Text = "Cost of 1 Gallon of Paint";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(470, 104);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 17);
            this.label1.TabIndex = 15;
            this.label1.Text = "$";
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.titleLabel.Location = new System.Drawing.Point(245, 9);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(331, 31);
            this.titleLabel.TabIndex = 16;
            this.titleLabel.Text = "Estimated price caculation";
            // 
            // Form1
            // 
            this.AcceptButton = this.caculateButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(248)))), ((int)(((byte)(248)))));
            this.ClientSize = new System.Drawing.Size(800, 328);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this._1GalPaintCostDescLabel);
            this.Controls.Add(this.wallSpaceLabel);
            this.Controls.Add(this._1GalPaintCostTextBox);
            this.Controls.Add(this.wallSpaceTextBox);
            this.Controls.Add(this.caculateButton);
            this.Controls.Add(this.totalCostLabel);
            this.Controls.Add(this.totalCostDescLabel);
            this.Controls.Add(this.laborCostLabel);
            this.Controls.Add(this.laborCostDescLabel);
            this.Controls.Add(this.paintCostLabel);
            this.Controls.Add(this.paintCostDescLabel);
            this.Controls.Add(this.hoursLabel);
            this.Controls.Add(this.workHoursDescLabel);
            this.Controls.Add(this.paintGallonLabel);
            this.Controls.Add(this.paintGallonDescLabel);
            this.Name = "Form1";
            this.Text = "Price Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label paintGallonDescLabel;
        private System.Windows.Forms.Label paintGallonLabel;
        private System.Windows.Forms.Label hoursLabel;
        private System.Windows.Forms.Label workHoursDescLabel;
        private System.Windows.Forms.Label paintCostLabel;
        private System.Windows.Forms.Label paintCostDescLabel;
        private System.Windows.Forms.Label laborCostLabel;
        private System.Windows.Forms.Label laborCostDescLabel;
        private System.Windows.Forms.Label totalCostLabel;
        private System.Windows.Forms.Label totalCostDescLabel;
        private System.Windows.Forms.Button caculateButton;
        private System.Windows.Forms.TextBox wallSpaceTextBox;
        private System.Windows.Forms.TextBox _1GalPaintCostTextBox;
        private System.Windows.Forms.Label wallSpaceLabel;
        private System.Windows.Forms.Label _1GalPaintCostDescLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label titleLabel;
    }
}

