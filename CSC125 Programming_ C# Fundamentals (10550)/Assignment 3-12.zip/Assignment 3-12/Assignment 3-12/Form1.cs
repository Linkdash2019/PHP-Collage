﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_3_12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void caculateButton_Click(object sender, EventArgs e)
        {
            double wallspacework;
            int wallspace;
            double calcpaintcost;
            try
            {
                //Parse wallSpaceTextBox
                wallspacework = double.Parse(wallSpaceTextBox.Text);
                wallspacework = wallspacework /= 115.0;
                wallspace = (int)Math.Ceiling(wallspacework);

                //Parse Paint Cost
                calcpaintcost = double.Parse(_1GalPaintCostTextBox.Text);
            }
            catch
            {
                wallspacework = 0;
                wallspace = 0;
                calcpaintcost = 0;
                MessageBox.Show("Bad info provided!");
            }

            //Math!
            string hourslabel = (wallspace * 8).ToString() + " Hour(s)";
            string laborcost = (wallspace * 20 * 8).ToString("C");
            string paint = (wallspace).ToString() + " Gallon(s)";
            string paintcost = (wallspace * calcpaintcost).ToString("C");
            string finalcost = ((wallspace * calcpaintcost) + (wallspace * 20 * 8)).ToString("C");

            //Setting Labels
            hoursLabel.Text = hourslabel;
            laborCostLabel.Text = laborcost;
            paintGallonLabel.Text = paint;
            paintCostLabel.Text = paintcost;
            totalCostLabel.Text = finalcost;

        }
    }
}
