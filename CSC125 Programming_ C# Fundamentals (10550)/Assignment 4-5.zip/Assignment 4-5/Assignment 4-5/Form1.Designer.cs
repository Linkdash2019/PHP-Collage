﻿namespace Assignment_4_5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fromBox = new System.Windows.Forms.GroupBox();
            this.fromListBox = new System.Windows.Forms.ListBox();
            this.toBox = new System.Windows.Forms.GroupBox();
            this.toListBox = new System.Windows.Forms.ListBox();
            this.descriptionLabel = new System.Windows.Forms.Label();
            this.distanceTextBox = new System.Windows.Forms.TextBox();
            this.convertDesc = new System.Windows.Forms.Label();
            this.convButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.convMeasure = new System.Windows.Forms.Label();
            this.fromBox.SuspendLayout();
            this.toBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // fromBox
            // 
            this.fromBox.Controls.Add(this.fromListBox);
            this.fromBox.Location = new System.Drawing.Point(13, 74);
            this.fromBox.Name = "fromBox";
            this.fromBox.Size = new System.Drawing.Size(133, 126);
            this.fromBox.TabIndex = 0;
            this.fromBox.TabStop = false;
            this.fromBox.Text = "From";
            // 
            // fromListBox
            // 
            this.fromListBox.FormattingEnabled = true;
            this.fromListBox.Items.AddRange(new object[] {
            "Inches",
            "Feet",
            "Yards"});
            this.fromListBox.Location = new System.Drawing.Point(6, 25);
            this.fromListBox.Name = "fromListBox";
            this.fromListBox.Size = new System.Drawing.Size(120, 95);
            this.fromListBox.TabIndex = 0;
            // 
            // toBox
            // 
            this.toBox.Controls.Add(this.toListBox);
            this.toBox.Location = new System.Drawing.Point(152, 74);
            this.toBox.Name = "toBox";
            this.toBox.Size = new System.Drawing.Size(133, 126);
            this.toBox.TabIndex = 1;
            this.toBox.TabStop = false;
            this.toBox.Text = "To";
            // 
            // toListBox
            // 
            this.toListBox.FormattingEnabled = true;
            this.toListBox.Items.AddRange(new object[] {
            "Inches",
            "Feet",
            "Yards"});
            this.toListBox.Location = new System.Drawing.Point(6, 25);
            this.toListBox.Name = "toListBox";
            this.toListBox.Size = new System.Drawing.Size(120, 95);
            this.toListBox.TabIndex = 0;
            // 
            // descriptionLabel
            // 
            this.descriptionLabel.AutoSize = true;
            this.descriptionLabel.Location = new System.Drawing.Point(41, 26);
            this.descriptionLabel.Name = "descriptionLabel";
            this.descriptionLabel.Size = new System.Drawing.Size(129, 13);
            this.descriptionLabel.TabIndex = 2;
            this.descriptionLabel.Text = "Enter distance to convert:";
            // 
            // distanceTextBox
            // 
            this.distanceTextBox.Location = new System.Drawing.Point(168, 23);
            this.distanceTextBox.Name = "distanceTextBox";
            this.distanceTextBox.Size = new System.Drawing.Size(100, 20);
            this.distanceTextBox.TabIndex = 3;
            // 
            // convertDesc
            // 
            this.convertDesc.AutoSize = true;
            this.convertDesc.Location = new System.Drawing.Point(27, 214);
            this.convertDesc.Name = "convertDesc";
            this.convertDesc.Size = new System.Drawing.Size(119, 13);
            this.convertDesc.TabIndex = 4;
            this.convertDesc.Text = "Converted measurment:";
            // 
            // convButton
            // 
            this.convButton.Location = new System.Drawing.Point(63, 245);
            this.convButton.Name = "convButton";
            this.convButton.Size = new System.Drawing.Size(75, 23);
            this.convButton.TabIndex = 6;
            this.convButton.Text = "C&onvert";
            this.convButton.UseVisualStyleBackColor = true;
            this.convButton.Click += new System.EventHandler(this.convButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(152, 245);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // convMeasure
            // 
            this.convMeasure.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.convMeasure.Location = new System.Drawing.Point(147, 210);
            this.convMeasure.Name = "convMeasure";
            this.convMeasure.Size = new System.Drawing.Size(100, 23);
            this.convMeasure.TabIndex = 8;
            this.convMeasure.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(297, 293);
            this.Controls.Add(this.convMeasure);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.convButton);
            this.Controls.Add(this.convertDesc);
            this.Controls.Add(this.distanceTextBox);
            this.Controls.Add(this.descriptionLabel);
            this.Controls.Add(this.toBox);
            this.Controls.Add(this.fromBox);
            this.Name = "Form1";
            this.Text = "Converter";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.fromBox.ResumeLayout(false);
            this.toBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox fromBox;
        private System.Windows.Forms.ListBox fromListBox;
        private System.Windows.Forms.GroupBox toBox;
        private System.Windows.Forms.ListBox toListBox;
        private System.Windows.Forms.Label descriptionLabel;
        private System.Windows.Forms.TextBox distanceTextBox;
        private System.Windows.Forms.Label convertDesc;
        private System.Windows.Forms.Button convButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label convMeasure;
    }
}

