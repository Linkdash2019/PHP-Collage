﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_4_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void convButton_Click(object sender, EventArgs e)
        {
            string fromItem;
            string toItem;
            if (fromListBox.SelectedIndex != -1) { fromItem = fromListBox.SelectedItem.ToString(); }
            else { fromItem = "ERROR";}
            if (toListBox.SelectedIndex != -1) { toItem = toListBox.SelectedItem.ToString(); }
            else { toItem = "ERROR"; }
            double conversion;
            if (double.TryParse(distanceTextBox.Text, out double number))
            {
                if (fromItem == "Inches")
                {
                    if (toItem == "Inches")
                    {
                        convMeasure.Text = distanceTextBox.Text;
                    }
                    else if (toItem == "Feet")
                    {
                        conversion = number/12;
                        convMeasure.Text = conversion.ToString();
                    }
                    else if (toItem == "Yards")
                    {
                        conversion = number/36;
                        convMeasure.Text = conversion.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Select an item");
                    }
                }
                else if (fromItem == "Feet")
                {
                    if (toItem == "Inches")
                    {
                        conversion = number * 12;
                        convMeasure.Text = conversion.ToString();
                    }
                    else if (toItem == "Feet")
                    {
                        convMeasure.Text = distanceTextBox.Text;
                    }
                    else if (toItem == "Yards")
                    {
                        conversion = number / 3;
                        convMeasure.Text = conversion.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Select an item");
                    }
                }
                else if (fromItem == "Yards")
                {
                    if (toItem == "Inches")
                    {
                        conversion = number * 36;
                        convMeasure.Text = conversion.ToString();
                    }
                    else if (toItem == "Feet")
                    {
                        conversion = number * 3;
                        convMeasure.Text = conversion.ToString();
                        
                    }
                    else if (toItem == "Yards")
                    {
                        convMeasure.Text = distanceTextBox.Text;
                    }
                    else
                    {
                        MessageBox.Show("Select an item");
                    }
                }
                else
                {
                    MessageBox.Show("Select an item");
                }
            }
            else
            {
                convMeasure.Text = "";
                MessageBox.Show("Invalid text entered");
            }
            
        }
    }
}
