﻿namespace Assignment_6_10
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.rockPictureBox = new System.Windows.Forms.PictureBox();
            this.paperPictureBox = new System.Windows.Forms.PictureBox();
            this.scissorsPictureBox = new System.Windows.Forms.PictureBox();
            this.rockLabel = new System.Windows.Forms.Label();
            this.scissorsLabel = new System.Windows.Forms.Label();
            this.paperLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.rockPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scissorsPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // rockPictureBox
            // 
            this.rockPictureBox.BackColor = System.Drawing.Color.White;
            this.rockPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rockPictureBox.Image = global::Assignment_6_10.Properties.Resources.Rock;
            this.rockPictureBox.Location = new System.Drawing.Point(12, 12);
            this.rockPictureBox.Name = "rockPictureBox";
            this.rockPictureBox.Size = new System.Drawing.Size(150, 218);
            this.rockPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.rockPictureBox.TabIndex = 0;
            this.rockPictureBox.TabStop = false;
            this.rockPictureBox.Click += new System.EventHandler(this.rockPictureBox_Click);
            // 
            // paperPictureBox
            // 
            this.paperPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.paperPictureBox.Image = global::Assignment_6_10.Properties.Resources.Paper;
            this.paperPictureBox.Location = new System.Drawing.Point(198, 12);
            this.paperPictureBox.Name = "paperPictureBox";
            this.paperPictureBox.Size = new System.Drawing.Size(150, 218);
            this.paperPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.paperPictureBox.TabIndex = 1;
            this.paperPictureBox.TabStop = false;
            this.paperPictureBox.Click += new System.EventHandler(this.paperPictureBox_Click);
            // 
            // scissorsPictureBox
            // 
            this.scissorsPictureBox.BackColor = System.Drawing.Color.White;
            this.scissorsPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.scissorsPictureBox.Image = global::Assignment_6_10.Properties.Resources.Scissors;
            this.scissorsPictureBox.Location = new System.Drawing.Point(379, 12);
            this.scissorsPictureBox.Name = "scissorsPictureBox";
            this.scissorsPictureBox.Size = new System.Drawing.Size(150, 218);
            this.scissorsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.scissorsPictureBox.TabIndex = 2;
            this.scissorsPictureBox.TabStop = false;
            this.scissorsPictureBox.Click += new System.EventHandler(this.scissorsPictureBox_Click);
            // 
            // rockLabel
            // 
            this.rockLabel.AutoSize = true;
            this.rockLabel.Font = new System.Drawing.Font("Rockwell", 12F);
            this.rockLabel.ForeColor = System.Drawing.Color.White;
            this.rockLabel.Location = new System.Drawing.Point(64, 233);
            this.rockLabel.Name = "rockLabel";
            this.rockLabel.Size = new System.Drawing.Size(45, 19);
            this.rockLabel.TabIndex = 3;
            this.rockLabel.Text = "Rock";
            // 
            // scissorsLabel
            // 
            this.scissorsLabel.AutoSize = true;
            this.scissorsLabel.Font = new System.Drawing.Font("Rockwell", 12F);
            this.scissorsLabel.ForeColor = System.Drawing.Color.White;
            this.scissorsLabel.Location = new System.Drawing.Point(418, 233);
            this.scissorsLabel.Name = "scissorsLabel";
            this.scissorsLabel.Size = new System.Drawing.Size(67, 19);
            this.scissorsLabel.TabIndex = 4;
            this.scissorsLabel.Text = "Scissors";
            // 
            // paperLabel
            // 
            this.paperLabel.AutoSize = true;
            this.paperLabel.Font = new System.Drawing.Font("Rockwell", 12F);
            this.paperLabel.ForeColor = System.Drawing.Color.White;
            this.paperLabel.Location = new System.Drawing.Point(245, 233);
            this.paperLabel.Name = "paperLabel";
            this.paperLabel.Size = new System.Drawing.Size(53, 19);
            this.paperLabel.TabIndex = 5;
            this.paperLabel.Text = "Paper";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.ClientSize = new System.Drawing.Size(542, 265);
            this.Controls.Add(this.paperLabel);
            this.Controls.Add(this.scissorsLabel);
            this.Controls.Add(this.rockLabel);
            this.Controls.Add(this.scissorsPictureBox);
            this.Controls.Add(this.paperPictureBox);
            this.Controls.Add(this.rockPictureBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Rock, Paper, Scissors!";
            ((System.ComponentModel.ISupportInitialize)(this.rockPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scissorsPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox rockPictureBox;
        private System.Windows.Forms.PictureBox paperPictureBox;
        private System.Windows.Forms.PictureBox scissorsPictureBox;
        private System.Windows.Forms.Label rockLabel;
        private System.Windows.Forms.Label scissorsLabel;
        private System.Windows.Forms.Label paperLabel;
    }
}

