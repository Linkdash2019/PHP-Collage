﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_6_10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Calculate
        private void Calculate(string userChoice, string cpuChoice)
        {
            if (userChoice == cpuChoice) { MessageBox.Show("You both used " + userChoice + ". No winners!"); }
            else if (userChoice == "rock") 
            {
                if (cpuChoice == "paper")
                {
                    MessageBox.Show("You used rock and the computer used paper.\nComputer Wins!");
                }
                else if(cpuChoice == "scissors")
                {
                    MessageBox.Show("You used rock and the computer used scissors.\nYou Win!");
                }
            }
            else if (userChoice == "paper") 
            {
                if (cpuChoice == "rock")
                {
                    MessageBox.Show("You used paper and the computer used rock.\nYou Win!");
                }
                else if (cpuChoice == "scissors")
                {
                    MessageBox.Show("You used paper and the computer used scissors.\nComputer Wins!");
                }
            }
            else if (userChoice == "scissors") 
            {
                if (cpuChoice == "rock")
                {
                    MessageBox.Show("You used scissors and the computer used rock.\nComputer Wins!");
                }
                else if (cpuChoice == "paper")
                {
                    MessageBox.Show("You used scissors and the computer used paper.\nYou Win!");
                }
            }
        }

        //computer choice
        private string ComputerChoice()
        {
            Random rnd = new Random();
            int randChoice = rnd.Next(1, 4);
            string compChoice;
            if (randChoice == 1)
            {
                compChoice = "rock";
            }
            else if (randChoice == 2)
            {
                compChoice = "paper";
            }
            else if (randChoice == 3)
            {
                compChoice = "scissors";
            }
            else
            {
                MessageBox.Show("COM picked invalid input!");
                compChoice = "rock";
            }
            return compChoice;
        }

        //user choice
        private void rockPictureBox_Click(object sender, EventArgs e)
        {
            string userPicked = "rock";
            string cpuPicked = ComputerChoice().ToString();
            Calculate(userPicked, cpuPicked);
        }

        private void paperPictureBox_Click(object sender, EventArgs e)
        {
            string userPicked = "paper";
            string cpuPicked = ComputerChoice().ToString();
            Calculate(userPicked, cpuPicked);
        }

        private void scissorsPictureBox_Click(object sender, EventArgs e)
        {
            string userPicked = "scissors";
            string cpuPicked = ComputerChoice().ToString();
            Calculate(userPicked, cpuPicked);
        }
    }
}
