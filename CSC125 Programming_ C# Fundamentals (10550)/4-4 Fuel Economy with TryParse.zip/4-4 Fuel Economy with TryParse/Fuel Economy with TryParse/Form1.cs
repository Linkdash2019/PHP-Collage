﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Fuel_Economy_with_TryParse
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            int miles;
            int gallons;
            int mPERg;

            if (int.TryParse(milesTextBox.Text, out miles))
            {
                if (int.TryParse(gallonsTextBox.Text, out gallons))
                {
                    mPERg = miles/gallons;
                    mpgLabel.Text = mPERg.ToString();
                }
                else
                {
                    MessageBox.Show("Gallon Fail");
                }
            }
            else
            {
                MessageBox.Show("Miles Fail");
            }
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
