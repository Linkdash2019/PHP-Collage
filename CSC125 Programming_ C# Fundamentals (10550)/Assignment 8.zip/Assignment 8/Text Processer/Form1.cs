﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Text_Processer
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            var vowelAmount = 0;
            var wordAmount = 0;
            string ogText = textBox.Text;

            //Get amount of variables
            if (ogText.Contains('a') | ogText.Contains('e') | ogText.Contains('i') | ogText.Contains('o') | ogText.Contains('u'))
            {
                foreach (var counter in ogText.ToLower())
                {
                    if (counter == 'a' | counter == 'e' | counter == 'i' | counter == 'o' | counter == 'u')
                    {
                        vowelAmount++;
                    }
                }
            }
            vowelCountLabel.Text = vowelAmount.ToString();

            //Get amout of words
            //First trim excess spaces
            ogText = ogText.Trim();
            while (ogText.Contains("  "))
            {
                ogText = ogText.Replace("  ", " ");
            }
            //Second split the string
            string[] tokens = ogText.Split(' ');
            foreach (string s in tokens)
            {
                wordAmount++;
            }
            //Third Check for empty input
            if (ogText == "")
            {
                wordAmount = 0;
                wordCountLabel.Text = wordAmount.ToString();
                vowelAmount = 0;
                vowelCountLabel.Text = vowelAmount.ToString();
                capitalizerLabel.Text = "";
                goto end;
            }
            wordCountLabel.Text = wordAmount.ToString();

            //Capitalize sentances
            bool periodfound = true;
            string newstr;
            List<string> capitalizedSentence = new List<string>();

            foreach (string s in tokens)
            {
                newstr = s;
                if (periodfound == true)
                {
                    periodfound = false;
                    newstr = s.Insert(0, char.ToUpper(s[0]).ToString());
                    newstr = newstr.Remove(1, 1);
                }
                if (s.EndsWith(".") | s.EndsWith("!") | s.EndsWith("?"))
                {
                    periodfound = true;                   
                }
                capitalizedSentence.Add(newstr);
            }
            capitalizerLabel.Text = string.Join(" ", capitalizedSentence);
        end:;
        }
    }
}
