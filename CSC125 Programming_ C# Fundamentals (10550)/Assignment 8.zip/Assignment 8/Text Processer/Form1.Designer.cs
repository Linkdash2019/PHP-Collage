﻿namespace Text_Processer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calcButton = new System.Windows.Forms.Button();
            this.textBox = new System.Windows.Forms.TextBox();
            this.capitalizerLabel = new System.Windows.Forms.Label();
            this.wordCountLabel = new System.Windows.Forms.Label();
            this.vowelCountLabel = new System.Windows.Forms.Label();
            this.instructionsLabel = new System.Windows.Forms.Label();
            this.capitalizerDescription = new System.Windows.Forms.Label();
            this.wordCounterDescription = new System.Windows.Forms.Label();
            this.vowelDescription = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(88, 84);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(75, 23);
            this.calcButton.TabIndex = 0;
            this.calcButton.Text = "Start";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // textBox
            // 
            this.textBox.Location = new System.Drawing.Point(21, 53);
            this.textBox.MaxLength = 37;
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(200, 20);
            this.textBox.TabIndex = 1;
            // 
            // capitalizerLabel
            // 
            this.capitalizerLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.capitalizerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.5F);
            this.capitalizerLabel.Location = new System.Drawing.Point(261, 93);
            this.capitalizerLabel.Name = "capitalizerLabel";
            this.capitalizerLabel.Size = new System.Drawing.Size(200, 23);
            this.capitalizerLabel.TabIndex = 2;
            this.capitalizerLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // wordCountLabel
            // 
            this.wordCountLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.wordCountLabel.Location = new System.Drawing.Point(264, 31);
            this.wordCountLabel.Name = "wordCountLabel";
            this.wordCountLabel.Size = new System.Drawing.Size(90, 23);
            this.wordCountLabel.TabIndex = 3;
            this.wordCountLabel.Text = "0";
            this.wordCountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // vowelCountLabel
            // 
            this.vowelCountLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.vowelCountLabel.Location = new System.Drawing.Point(368, 31);
            this.vowelCountLabel.Name = "vowelCountLabel";
            this.vowelCountLabel.Size = new System.Drawing.Size(90, 23);
            this.vowelCountLabel.TabIndex = 4;
            this.vowelCountLabel.Text = "0";
            this.vowelCountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // instructionsLabel
            // 
            this.instructionsLabel.AutoSize = true;
            this.instructionsLabel.Location = new System.Drawing.Point(44, 31);
            this.instructionsLabel.Name = "instructionsLabel";
            this.instructionsLabel.Size = new System.Drawing.Size(157, 13);
            this.instructionsLabel.TabIndex = 5;
            this.instructionsLabel.Text = "Enter some text then press Start";
            // 
            // capitalizerDescription
            // 
            this.capitalizerDescription.AutoSize = true;
            this.capitalizerDescription.Location = new System.Drawing.Point(287, 72);
            this.capitalizerDescription.Name = "capitalizerDescription";
            this.capitalizerDescription.Size = new System.Drawing.Size(147, 13);
            this.capitalizerDescription.TabIndex = 6;
            this.capitalizerDescription.Text = "Text with proper capitalization";
            // 
            // wordCounterDescription
            // 
            this.wordCounterDescription.AutoSize = true;
            this.wordCounterDescription.Location = new System.Drawing.Point(261, 9);
            this.wordCounterDescription.Name = "wordCounterDescription";
            this.wordCounterDescription.Size = new System.Drawing.Size(87, 13);
            this.wordCounterDescription.TabIndex = 7;
            this.wordCounterDescription.Text = "Number of words";
            // 
            // vowelDescription
            // 
            this.vowelDescription.AutoSize = true;
            this.vowelDescription.Location = new System.Drawing.Point(369, 9);
            this.vowelDescription.Name = "vowelDescription";
            this.vowelDescription.Size = new System.Drawing.Size(92, 13);
            this.vowelDescription.TabIndex = 8;
            this.vowelDescription.Text = "Number of vowels";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 142);
            this.Controls.Add(this.vowelDescription);
            this.Controls.Add(this.wordCounterDescription);
            this.Controls.Add(this.capitalizerDescription);
            this.Controls.Add(this.instructionsLabel);
            this.Controls.Add(this.vowelCountLabel);
            this.Controls.Add(this.wordCountLabel);
            this.Controls.Add(this.capitalizerLabel);
            this.Controls.Add(this.textBox);
            this.Controls.Add(this.calcButton);
            this.Name = "Form1";
            this.Text = "Text Formater";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.Label capitalizerLabel;
        private System.Windows.Forms.Label wordCountLabel;
        private System.Windows.Forms.Label vowelCountLabel;
        private System.Windows.Forms.Label instructionsLabel;
        private System.Windows.Forms.Label capitalizerDescription;
        private System.Windows.Forms.Label wordCounterDescription;
        private System.Windows.Forms.Label vowelDescription;
    }
}

