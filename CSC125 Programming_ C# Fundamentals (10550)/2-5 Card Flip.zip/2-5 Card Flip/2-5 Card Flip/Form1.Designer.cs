﻿namespace _2_5_Card_Flip
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cardFrontPictureBox = new System.Windows.Forms.PictureBox();
            this.cardBackPictureBox = new System.Windows.Forms.PictureBox();
            this.showBackButton = new System.Windows.Forms.Button();
            this.showFrontButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.cardFrontPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cardBackPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // cardFrontPictureBox
            // 
            this.cardFrontPictureBox.Image = global::_2_5_Card_Flip.Properties.Resources.Card_front;
            this.cardFrontPictureBox.Location = new System.Drawing.Point(334, 12);
            this.cardFrontPictureBox.Name = "cardFrontPictureBox";
            this.cardFrontPictureBox.Size = new System.Drawing.Size(245, 342);
            this.cardFrontPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.cardFrontPictureBox.TabIndex = 0;
            this.cardFrontPictureBox.TabStop = false;
            this.cardFrontPictureBox.Visible = false;
            // 
            // cardBackPictureBox
            // 
            this.cardBackPictureBox.Image = global::_2_5_Card_Flip.Properties.Resources.Card_back;
            this.cardBackPictureBox.Location = new System.Drawing.Point(35, 12);
            this.cardBackPictureBox.Name = "cardBackPictureBox";
            this.cardBackPictureBox.Size = new System.Drawing.Size(245, 342);
            this.cardBackPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.cardBackPictureBox.TabIndex = 1;
            this.cardBackPictureBox.TabStop = false;
            // 
            // showBackButton
            // 
            this.showBackButton.Location = new System.Drawing.Point(82, 374);
            this.showBackButton.Name = "showBackButton";
            this.showBackButton.Size = new System.Drawing.Size(140, 93);
            this.showBackButton.TabIndex = 2;
            this.showBackButton.Text = "Show back of the card";
            this.showBackButton.UseVisualStyleBackColor = true;
            this.showBackButton.Click += new System.EventHandler(this.showBackButton_Click);
            // 
            // showFrontButton
            // 
            this.showFrontButton.Location = new System.Drawing.Point(391, 374);
            this.showFrontButton.Name = "showFrontButton";
            this.showFrontButton.Size = new System.Drawing.Size(140, 93);
            this.showFrontButton.TabIndex = 3;
            this.showFrontButton.Text = "Show front of the card";
            this.showFrontButton.UseVisualStyleBackColor = true;
            this.showFrontButton.Click += new System.EventHandler(this.showFrontButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(621, 508);
            this.Controls.Add(this.showFrontButton);
            this.Controls.Add(this.showBackButton);
            this.Controls.Add(this.cardBackPictureBox);
            this.Controls.Add(this.cardFrontPictureBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Card Flip";
            ((System.ComponentModel.ISupportInitialize)(this.cardFrontPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cardBackPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox cardFrontPictureBox;
        private System.Windows.Forms.PictureBox cardBackPictureBox;
        private System.Windows.Forms.Button showBackButton;
        private System.Windows.Forms.Button showFrontButton;
    }
}

