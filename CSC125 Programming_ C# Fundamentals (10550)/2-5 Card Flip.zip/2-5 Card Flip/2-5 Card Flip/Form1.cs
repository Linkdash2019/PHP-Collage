﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2_5_Card_Flip
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void showBackButton_Click(object sender, EventArgs e)
        {
            if (cardBackPictureBox.Visible == true)
            {MessageBox.Show("Shuffling nothing into the draw pile!"); }
            cardBackPictureBox.Visible = true;
            cardFrontPictureBox.Visible = false;
            //showBackButton.Visible = false;
            //showFrontButton.Visible = true;
        }

        private void showFrontButton_Click(object sender, EventArgs e)
        {
            if (cardFrontPictureBox.Visible == true)
            {MessageBox.Show("You are out of useable cards and are unable to draw!"); }
            cardBackPictureBox.Visible = false;
            cardFrontPictureBox.Visible = true;
            //showBackButton.Visible = true;
            //showFrontButton.Visible = false;
        }
    }
}
