﻿namespace Final_Project_Draft
{
    partial class Blocks_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Blocks_Menu));
            this.copyPasteButton = new System.Windows.Forms.Button();
            this.loadButton = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.saveButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.infoButton = new System.Windows.Forms.Button();
            this.buildButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // copyPasteButton
            // 
            this.copyPasteButton.Location = new System.Drawing.Point(12, 12);
            this.copyPasteButton.Name = "copyPasteButton";
            this.copyPasteButton.Size = new System.Drawing.Size(108, 48);
            this.copyPasteButton.TabIndex = 0;
            this.copyPasteButton.Text = "Copy/Paste structure";
            this.copyPasteButton.UseVisualStyleBackColor = true;
            this.copyPasteButton.Click += new System.EventHandler(this.copyButton_Click);
            // 
            // loadButton
            // 
            this.loadButton.Location = new System.Drawing.Point(240, 12);
            this.loadButton.Name = "loadButton";
            this.loadButton.Size = new System.Drawing.Size(108, 48);
            this.loadButton.TabIndex = 1;
            this.loadButton.Text = "Load and place structure";
            this.loadButton.UseVisualStyleBackColor = true;
            this.loadButton.Click += new System.EventHandler(this.loadButton_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.DefaultExt = "block";
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "\"Minecraft structure files (*.block)|*.block|All files (*.*)|*.*\"";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "block";
            this.saveFileDialog1.FileName = "*.block";
            this.saveFileDialog1.Filter = "\"Minecraft structure files (*.block)|*.block\"";
            this.saveFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.saveFileDialog1_FileOk);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(126, 12);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(108, 48);
            this.saveButton.TabIndex = 2;
            this.saveButton.Text = "Save structure";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(184, 115);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(163, 23);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Back";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // infoButton
            // 
            this.infoButton.Location = new System.Drawing.Point(12, 115);
            this.infoButton.Name = "infoButton";
            this.infoButton.Size = new System.Drawing.Size(163, 23);
            this.infoButton.TabIndex = 4;
            this.infoButton.Text = "Info/Help";
            this.infoButton.UseVisualStyleBackColor = true;
            this.infoButton.Click += new System.EventHandler(this.infoButton_Click);
            // 
            // buildButton
            // 
            this.buildButton.Location = new System.Drawing.Point(12, 66);
            this.buildButton.Name = "buildButton";
            this.buildButton.Size = new System.Drawing.Size(335, 43);
            this.buildButton.TabIndex = 5;
            this.buildButton.Text = "Build structure building box";
            this.buildButton.UseVisualStyleBackColor = true;
            this.buildButton.Click += new System.EventHandler(this.buildButton_Click);
            // 
            // Blocks_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(359, 146);
            this.ControlBox = false;
            this.Controls.Add(this.buildButton);
            this.Controls.Add(this.infoButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.loadButton);
            this.Controls.Add(this.copyPasteButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Blocks_Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button copyPasteButton;
        private System.Windows.Forms.Button loadButton;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button infoButton;
        private System.Windows.Forms.Button buildButton;
    }
}