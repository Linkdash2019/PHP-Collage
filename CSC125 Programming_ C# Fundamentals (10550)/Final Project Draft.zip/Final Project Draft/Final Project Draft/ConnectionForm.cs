﻿using MinecraftPiAPI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project_Draft
{
    public partial class ConnectionForm: Form
    {
        public ConnectionForm()
        {
            InitializeComponent();
        }

        private async void testNetButton_Click(object sender, EventArgs e)
        {
            testNetButton.Text = "Connecting...";
            testNetButton.Enabled = false;
            
            bool valid = true;
            string ipAddress = ipTextBox.Text.ToString();
            try { IPAddress.Parse(ipAddress); }
            catch { MessageBox.Show("An invalid IP address was given", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop); valid = false; }
            
            int port = 0;
            try { port = int.Parse(portTextbox.Text.ToString()); }
            catch { MessageBox.Show("An invalid port was given", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop); valid = false; }

            if (valid)
            {
                Minecraft minecraft;
                
                try { minecraft = new Minecraft(ipAddress, port); }
                catch { minecraft = null; testNetButton.Text = "Connect"; testNetButton.Enabled = true; return; }
                minecraft.Chat.Post("A C# User joined the game!");
                Controller controller = new Controller(minecraft);
                controller.Show();
                StreamWriter file1 = new StreamWriter("saved_ip.txt");
                file1.Write(ipTextBox.Text);
                file1.Close();
                StreamWriter file2 = new StreamWriter("saved_port.txt");
                file2.Write(portTextbox.Text);
                file2.Close();
                this.Close();
            }
            else
            {
                testNetButton.Text = "Connect"; 
                testNetButton.Enabled = true;
            }
            
        }

        private void ConnectionForm_Load(object sender, EventArgs e)
        {
            try { ipTextBox.Text = File.ReadAllText("saved_ip.txt".Trim()); }
            catch
            {
                using (System.IO.StreamWriter file = new System.IO.StreamWriter("saved_ip.txt"))
                {
                    file.Write("");
                    file.Close();
                    ipTextBox.Text = File.ReadAllText("saved_ip.txt".Trim());
                    file.Close();
                }
            }

            try { portTextbox.Text = File.ReadAllText("saved_port.txt".Trim()); }
            catch
            {
                using (System.IO.StreamWriter file = new System.IO.StreamWriter("saved_port.txt"))
                {
                    file.Write("4711");
                    file.Close();
                    portTextbox.Text = File.ReadAllText("saved_port.txt".Trim());
                    file.Close();
                }
            }
        }
    }
}
