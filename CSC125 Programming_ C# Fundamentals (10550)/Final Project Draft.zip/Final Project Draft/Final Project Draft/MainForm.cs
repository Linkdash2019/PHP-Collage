﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project_Draft
{
    public partial class welcomeForm: Form
    {
        public welcomeForm()
        {
            InitializeComponent();
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            ConnectionForm mainWindow = new ConnectionForm();
            mainWindow.Show();
            this.Hide();
            this.Close();
        }
    }
}
