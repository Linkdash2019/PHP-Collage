﻿namespace Final_Project_Draft
{
    partial class teleport_Custom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(teleport_Custom));
            this.descLabel = new System.Windows.Forms.Label();
            this.X = new System.Windows.Forms.NumericUpDown();
            this.Z = new System.Windows.Forms.NumericUpDown();
            this.Y = new System.Windows.Forms.NumericUpDown();
            this.goButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pitchLabel = new System.Windows.Forms.Label();
            this.pitchUpDown = new System.Windows.Forms.NumericUpDown();
            this.rotationLabel = new System.Windows.Forms.Label();
            this.rotationUpDown = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.X)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Z)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pitchUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rotationUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // descLabel
            // 
            this.descLabel.AutoSize = true;
            this.descLabel.Location = new System.Drawing.Point(115, 33);
            this.descLabel.Name = "descLabel";
            this.descLabel.Size = new System.Drawing.Size(84, 13);
            this.descLabel.TabIndex = 0;
            this.descLabel.Text = "Teleport where?";
            // 
            // X
            // 
            this.X.DecimalPlaces = 2;
            this.X.Location = new System.Drawing.Point(34, 68);
            this.X.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.X.Minimum = new decimal(new int[] {
            256,
            0,
            0,
            -2147483648});
            this.X.Name = "X";
            this.X.Size = new System.Drawing.Size(66, 20);
            this.X.TabIndex = 1;
            // 
            // Z
            // 
            this.Z.DecimalPlaces = 2;
            this.Z.Location = new System.Drawing.Point(207, 68);
            this.Z.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.Z.Minimum = new decimal(new int[] {
            256,
            0,
            0,
            -2147483648});
            this.Z.Name = "Z";
            this.Z.Size = new System.Drawing.Size(66, 20);
            this.Z.TabIndex = 3;
            // 
            // Y
            // 
            this.Y.DecimalPlaces = 2;
            this.Y.Location = new System.Drawing.Point(120, 68);
            this.Y.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.Y.Minimum = new decimal(new int[] {
            256,
            0,
            0,
            -2147483648});
            this.Y.Name = "Y";
            this.Y.Size = new System.Drawing.Size(66, 20);
            this.Y.TabIndex = 2;
            // 
            // goButton
            // 
            this.goButton.Location = new System.Drawing.Point(117, 197);
            this.goButton.Name = "goButton";
            this.goButton.Size = new System.Drawing.Size(75, 23);
            this.goButton.TabIndex = 4;
            this.goButton.Text = "Go!";
            this.goButton.UseVisualStyleBackColor = true;
            this.goButton.Click += new System.EventHandler(this.goButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "X:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(191, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Z:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(105, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Y:";
            // 
            // pitchLabel
            // 
            this.pitchLabel.AutoSize = true;
            this.pitchLabel.Location = new System.Drawing.Point(79, 119);
            this.pitchLabel.Name = "pitchLabel";
            this.pitchLabel.Size = new System.Drawing.Size(31, 13);
            this.pitchLabel.TabIndex = 15;
            this.pitchLabel.Text = "Pitch";
            // 
            // pitchUpDown
            // 
            this.pitchUpDown.DecimalPlaces = 2;
            this.pitchUpDown.Location = new System.Drawing.Point(66, 145);
            this.pitchUpDown.Maximum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.pitchUpDown.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            -2147483648});
            this.pitchUpDown.Name = "pitchUpDown";
            this.pitchUpDown.Size = new System.Drawing.Size(66, 20);
            this.pitchUpDown.TabIndex = 16;
            // 
            // rotationLabel
            // 
            this.rotationLabel.AutoSize = true;
            this.rotationLabel.Location = new System.Drawing.Point(176, 119);
            this.rotationLabel.Name = "rotationLabel";
            this.rotationLabel.Size = new System.Drawing.Size(47, 13);
            this.rotationLabel.TabIndex = 17;
            this.rotationLabel.Text = "Rotation";
            // 
            // rotationUpDown
            // 
            this.rotationUpDown.DecimalPlaces = 2;
            this.rotationUpDown.Location = new System.Drawing.Point(169, 145);
            this.rotationUpDown.Maximum = new decimal(new int[] {
            180,
            0,
            0,
            0});
            this.rotationUpDown.Minimum = new decimal(new int[] {
            180,
            0,
            0,
            -2147483648});
            this.rotationUpDown.Name = "rotationUpDown";
            this.rotationUpDown.Size = new System.Drawing.Size(66, 20);
            this.rotationUpDown.TabIndex = 18;
            // 
            // teleport_Custom
            // 
            this.AcceptButton = this.goButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(312, 242);
            this.ControlBox = false;
            this.Controls.Add(this.rotationUpDown);
            this.Controls.Add(this.rotationLabel);
            this.Controls.Add(this.pitchUpDown);
            this.Controls.Add(this.pitchLabel);
            this.Controls.Add(this.goButton);
            this.Controls.Add(this.Y);
            this.Controls.Add(this.Z);
            this.Controls.Add(this.X);
            this.Controls.Add(this.descLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "teleport_Custom";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Teleport Menu";
            ((System.ComponentModel.ISupportInitialize)(this.X)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Z)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pitchUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rotationUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label descLabel;
        private System.Windows.Forms.NumericUpDown X;
        private System.Windows.Forms.NumericUpDown Z;
        private System.Windows.Forms.NumericUpDown Y;
        private System.Windows.Forms.Button goButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label pitchLabel;
        private System.Windows.Forms.NumericUpDown pitchUpDown;
        private System.Windows.Forms.Label rotationLabel;
        private System.Windows.Forms.NumericUpDown rotationUpDown;
    }
}