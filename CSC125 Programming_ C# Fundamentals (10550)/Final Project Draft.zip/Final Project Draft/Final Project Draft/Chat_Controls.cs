﻿using MinecraftPiAPI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project_Draft
{
    internal partial class Chat: Form
    {
        bool exiting = false;
        private Minecraft minecraft;
        public Chat(Minecraft minecraft)
        {
            InitializeComponent();
            this.minecraft = minecraft;
            chat_loop();
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            exiting = true;
            this.Close();
        }

        private void sendButton_Click(object sender, EventArgs e)
        {
            minecraft.Chat.Post("<C# User> " + chatTextBox.Text);
            chatterBox.Items.Add("<C# User> " + chatTextBox.Text);
            chatTextBox.Text = "";
        }

        private async void chat_loop()
        {
            while (true)
            {
                string[] message = minecraft.Chat.PollChatPosts();
                string lastmessage = message[0];
                if (lastmessage != "\n") { chatterBox.Items.Add(lastmessage); } 
                await Task.Delay(10);
                if (exiting) { break; }
            }
        }
    }
}
