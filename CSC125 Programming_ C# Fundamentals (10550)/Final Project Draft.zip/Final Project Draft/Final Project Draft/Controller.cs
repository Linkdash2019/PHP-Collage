﻿using MinecraftPiAPI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project_Draft
{
    
    internal partial class Controller : Form
    {
        private Minecraft minecraft;
        private string[] chat;
        public Controller(Minecraft minecraft)
        {
            InitializeComponent();
            this.minecraft = minecraft;
            this.chat = minecraft.Chat.PollChatPosts(); 
        }

        private void Controller_FormClosing(object sender, FormClosingEventArgs e)
        {
            minecraft.Chat.Post("A C# User has left the game!");
        }

        private void chatButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            using (Chat chat = new Chat(minecraft))
            {
                chat.ShowDialog();
            }
            this.Show();
        }

        private void teleportButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            using (Teleport_Main teleport_Main= new Teleport_Main(minecraft))
            {
                teleport_Main.ShowDialog();
            }
            this.Show();
        }

        private void blocksButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            using (Blocks_Menu blocks_Menu = new Blocks_Menu(minecraft))
            {
                blocks_Menu.ShowDialog();
            }
            this.Show();
        }

        private void copyButton_Click(object sender, EventArgs e)
        {
             minecraft.World.SaveWorld();
            if (this.worldPaste.Enabled == false)
            {
                this.worldPaste.Enabled = true;
            }
        }

        private void pasteButton_Click(object sender, EventArgs e)
        {
            minecraft.World.RestoreWorld();
        }
    }
}
