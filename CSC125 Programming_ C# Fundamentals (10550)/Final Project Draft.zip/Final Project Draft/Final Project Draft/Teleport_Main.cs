﻿using MinecraftPiAPI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project_Draft
{
    internal partial class Teleport_Main: Form
    {
        bool exiting = false;
        private Minecraft minecraft;
        public Teleport_Main(Minecraft minecraft)
        {
            InitializeComponent();
            this.minecraft = minecraft;
        }

        private void spawnButton_Click(object sender, EventArgs e)
        {
            minecraft.Player.Position.Set(0.50, minecraft.World.Height(0,0),0.50);
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            exiting = true;
            this.Close();
        }

        private void customButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            using (teleport_Custom teleport_Custom = new teleport_Custom(minecraft))
            {
                teleport_Custom.ShowDialog();
            }
            this.Show();
        }

        private async void cords_loop(object sender, EventArgs e)
        {
            while (true)
            {
                int playerX = (int)minecraft.Player.Position.Get().X;
                int playerY = (int)minecraft.Player.Position.Get().Y;
                int playerZ = (int)minecraft.Player.Position.Get().Z;
                cordsLabel.Text = "Player is at: X: " + playerX + ", Y: " + playerY + ", Z: " + playerZ;
                await Task.Delay(10);
                if (exiting) { break; }
            }   
        }
    }
}
