﻿namespace Final_Project_Draft
{
    partial class Controller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Controller));
            this.chatButton = new System.Windows.Forms.Button();
            this.teleportButton = new System.Windows.Forms.Button();
            this.blocksButton = new System.Windows.Forms.Button();
            this.copyButton = new System.Windows.Forms.Button();
            this.worldPaste = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // chatButton
            // 
            this.chatButton.Location = new System.Drawing.Point(12, 12);
            this.chatButton.Name = "chatButton";
            this.chatButton.Size = new System.Drawing.Size(75, 23);
            this.chatButton.TabIndex = 0;
            this.chatButton.Text = "Chat";
            this.chatButton.UseVisualStyleBackColor = true;
            this.chatButton.Click += new System.EventHandler(this.chatButton_Click);
            // 
            // teleportButton
            // 
            this.teleportButton.Location = new System.Drawing.Point(93, 12);
            this.teleportButton.Name = "teleportButton";
            this.teleportButton.Size = new System.Drawing.Size(75, 23);
            this.teleportButton.TabIndex = 1;
            this.teleportButton.Text = "Teleport";
            this.teleportButton.UseVisualStyleBackColor = true;
            this.teleportButton.Click += new System.EventHandler(this.teleportButton_Click);
            // 
            // blocksButton
            // 
            this.blocksButton.Location = new System.Drawing.Point(174, 12);
            this.blocksButton.Name = "blocksButton";
            this.blocksButton.Size = new System.Drawing.Size(75, 23);
            this.blocksButton.TabIndex = 2;
            this.blocksButton.Text = "Blocks";
            this.blocksButton.UseVisualStyleBackColor = true;
            this.blocksButton.Click += new System.EventHandler(this.blocksButton_Click);
            // 
            // copyButton
            // 
            this.copyButton.Location = new System.Drawing.Point(46, 41);
            this.copyButton.Name = "copyButton";
            this.copyButton.Size = new System.Drawing.Size(75, 34);
            this.copyButton.TabIndex = 3;
            this.copyButton.Text = "Copy World";
            this.copyButton.UseVisualStyleBackColor = true;
            this.copyButton.Click += new System.EventHandler(this.copyButton_Click);
            // 
            // worldPaste
            // 
            this.worldPaste.Enabled = false;
            this.worldPaste.Location = new System.Drawing.Point(127, 41);
            this.worldPaste.Name = "worldPaste";
            this.worldPaste.Size = new System.Drawing.Size(75, 34);
            this.worldPaste.TabIndex = 4;
            this.worldPaste.Text = "Paste World";
            this.worldPaste.UseVisualStyleBackColor = true;
            this.worldPaste.Click += new System.EventHandler(this.pasteButton_Click);
            // 
            // Controller
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(257, 89);
            this.Controls.Add(this.worldPaste);
            this.Controls.Add(this.copyButton);
            this.Controls.Add(this.blocksButton);
            this.Controls.Add(this.teleportButton);
            this.Controls.Add(this.chatButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Controller";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MCPi Remote Control";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Controller_FormClosing);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button chatButton;
        private System.Windows.Forms.Button teleportButton;
        private System.Windows.Forms.Button blocksButton;
        private System.Windows.Forms.Button copyButton;
        private System.Windows.Forms.Button worldPaste;
    }
}