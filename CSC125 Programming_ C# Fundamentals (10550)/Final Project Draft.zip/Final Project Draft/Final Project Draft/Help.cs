﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project_Draft
{
    partial class Help : Form
    {
        public Help()
        {
            InitializeComponent();
            //this.Text = String.Format("About {0}", AssemblyTitle);
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
