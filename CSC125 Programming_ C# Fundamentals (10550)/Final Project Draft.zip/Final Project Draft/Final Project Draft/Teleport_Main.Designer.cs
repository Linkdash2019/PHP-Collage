﻿namespace Final_Project_Draft
{
    partial class Teleport_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Teleport_Main));
            this.spawnButton = new System.Windows.Forms.Button();
            this.descLabel = new System.Windows.Forms.Label();
            this.customButton = new System.Windows.Forms.Button();
            this.backButton = new System.Windows.Forms.Button();
            this.cordsLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // spawnButton
            // 
            this.spawnButton.Location = new System.Drawing.Point(26, 70);
            this.spawnButton.Name = "spawnButton";
            this.spawnButton.Size = new System.Drawing.Size(75, 23);
            this.spawnButton.TabIndex = 0;
            this.spawnButton.Text = "Spawn";
            this.spawnButton.UseVisualStyleBackColor = true;
            this.spawnButton.Click += new System.EventHandler(this.spawnButton_Click);
            // 
            // descLabel
            // 
            this.descLabel.AutoSize = true;
            this.descLabel.Location = new System.Drawing.Point(70, 45);
            this.descLabel.Name = "descLabel";
            this.descLabel.Size = new System.Drawing.Size(84, 13);
            this.descLabel.TabIndex = 1;
            this.descLabel.Text = "Teleport where?";
            // 
            // customButton
            // 
            this.customButton.Location = new System.Drawing.Point(121, 70);
            this.customButton.Name = "customButton";
            this.customButton.Size = new System.Drawing.Size(75, 23);
            this.customButton.TabIndex = 2;
            this.customButton.Text = "Custom";
            this.customButton.UseVisualStyleBackColor = true;
            this.customButton.Click += new System.EventHandler(this.customButton_Click);
            // 
            // backButton
            // 
            this.backButton.Location = new System.Drawing.Point(73, 99);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(75, 23);
            this.backButton.TabIndex = 3;
            this.backButton.Text = "Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // cordsLabel
            // 
            this.cordsLabel.Location = new System.Drawing.Point(12, 9);
            this.cordsLabel.Name = "cordsLabel";
            this.cordsLabel.Size = new System.Drawing.Size(203, 13);
            this.cordsLabel.TabIndex = 4;
            this.cordsLabel.Text = "Player is at: X: ??, Y: ??, Z: ??";
            // 
            // Teleport_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(227, 147);
            this.ControlBox = false;
            this.Controls.Add(this.cordsLabel);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.customButton);
            this.Controls.Add(this.descLabel);
            this.Controls.Add(this.spawnButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Teleport_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Teleport Menu";
            this.Load += new System.EventHandler(this.cords_loop);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button spawnButton;
        private System.Windows.Forms.Label descLabel;
        private System.Windows.Forms.Button customButton;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.Label cordsLabel;
    }
}