﻿using MinecraftPiAPI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project_Draft
{
    internal partial class teleport_Custom: Form
    {
        private Minecraft minecraft;
        public teleport_Custom(Minecraft minecraft)
        {
            InitializeComponent();
            this.minecraft = minecraft;
        }

        private void goButton_Click(object sender, EventArgs e)
        {
            minecraft.Player.Position.Set(Convert.ToDouble(X.Text), Convert.ToDouble(Y.Text), Convert.ToDouble(Z.Text));
            //minecraft.Player.Position.SetDirection((int)X2.Value, (int)Y2.Value, (int)Z2.Value);
            minecraft.Player.Position.SetPitch(pitchUpDown.Value);
            minecraft.Player.Position.SetRotation(rotationUpDown.Value);
            this.Close();
        }
    }
}
