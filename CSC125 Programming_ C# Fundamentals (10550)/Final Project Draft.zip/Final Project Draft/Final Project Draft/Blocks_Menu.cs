﻿using MinecraftPiAPI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project_Draft
{
    internal partial class Blocks_Menu: Form
    {
        private Minecraft minecraft;
        public Blocks_Menu(Minecraft minecraft)
        {
            InitializeComponent();
            this.minecraft = minecraft;
        }

        private void copyButton_Click(object sender, EventArgs e)
        {
            int[,] y1 = new int[3, 3];
            int[,] y2 = new int[3, 3];
            int[,] y3 = new int[3, 3];
            int counter = 0;

            //Get blocks
            while (counter != 3) 
            {
                y1[counter, 0] = minecraft.World.Block(counter, 57, 0).Id;
                y1[counter, 1] = minecraft.World.Block(counter, 57, 1).Id;
                y1[counter, 2] = minecraft.World.Block(counter, 57, 2).Id;

                y2[counter, 0] = minecraft.World.Block(counter, 58, 0).Id;
                y2[counter, 1] = minecraft.World.Block(counter, 58, 1).Id;
                y2[counter, 2] = minecraft.World.Block(counter, 58, 2).Id;
                
                y3[counter, 0] = minecraft.World.Block(counter, 59, 0).Id;
                y3[counter, 1] = minecraft.World.Block(counter, 59, 1).Id;
                y3[counter, 2] = minecraft.World.Block(counter, 59, 2).Id;
                counter++;
            }

            counter = 0;
            int playerx = (int)minecraft.Player.Position.Get().X;
            int playery = (int)minecraft.Player.Position.Get().Y;
            int playerz = (int)minecraft.Player.Position.Get().Z;

            //Place blocks
            while (counter != 3)
            {
                minecraft.World.Block(playerx + 1 + counter, playery, playerz + 1).Set(y1[counter, 0]);
                minecraft.World.Block(playerx + 1 + counter, playery, playerz + 2).Set(y1[counter, 1]);
                minecraft.World.Block(playerx + 1 + counter, playery, playerz + 3).Set(y1[counter, 2]);

                minecraft.World.Block(playerx + 1 + counter, playery + 1, playerz + 1).Set(y2[counter, 0]);
                minecraft.World.Block(playerx + 1 + counter, playery + 1, playerz + 2).Set(y2[counter, 1]);
                minecraft.World.Block(playerx + 1 + counter, playery + 1, playerz + 3).Set(y2[counter, 2]);

                minecraft.World.Block(playerx + 1 + counter, playery + 2, playerz + 1).Set(y3[counter, 0]);
                minecraft.World.Block(playerx + 1 + counter, playery + 2, playerz + 2).Set(y3[counter, 1]);
                minecraft.World.Block(playerx + 1 + counter, playery + 2, playerz + 3).Set(y3[counter, 2]);
                counter++;

            }

            //Save block to file
            using (System.IO.StreamWriter file = new System.IO.StreamWriter("3x3x3.block"))
            {
                //1st layer
                string line1 = y1[0, 0].ToString() + "," + y1[0, 1].ToString() + "," + y1[0, 2].ToString() + ",";
                string line2 = y1[1, 0].ToString() + "," + y1[1, 1].ToString() + "," + y1[1, 2].ToString() + ",";
                string line3 = y1[2, 0].ToString() + "," + y1[2, 1].ToString() + "," + y1[2, 2].ToString() + ",";
                file.WriteLine(line1);
                file.WriteLine(line2);
                file.WriteLine(line3);
                file.WriteLine(" ");
                
                //2nd layer
                line1 = y2[0, 0].ToString() + "," + y2[0, 1].ToString() + "," + y2[0, 2].ToString() + ",";
                line2 = y2[1, 0].ToString() + "," + y2[1, 1].ToString() + "," + y2[1, 2].ToString() + ",";
                line3 = y2[2, 0].ToString() + "," + y2[2, 1].ToString() + "," + y2[2, 2].ToString() + ",";
                file.WriteLine(line1);
                file.WriteLine(line2);
                file.WriteLine(line3);
                file.WriteLine(" ");
                
                //3rd layer
                line1 = y3[0, 0].ToString() + "," + y3[0, 1].ToString() + "," + y3[0, 2].ToString() + ",";
                line2 = y3[1, 0].ToString() + "," + y3[1, 1].ToString() + "," + y3[1, 2].ToString() + ",";
                line3 = y3[2, 0].ToString() + "," + y3[2, 1].ToString() + "," + y3[2, 2].ToString() + ",";
                file.WriteLine(line1);
                file.WriteLine(line2);
                file.WriteLine(line3);

            }

        }

        private void loadButton_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            //Read and Parse BLOCK file
            string readText = File.ReadAllText(openFileDialog1.FileName);
            string[] blockline = readText.Split(',');
            int[,] y1 = new int[3, 3];
            int[,] y2 = new int[3, 3];
            int[,] y3 = new int[3, 3];
            int counter_1 = 0;
            int counter_2 = 0;
            bool done1 = false;
            bool done2 = false;

            foreach (string x in blockline)
            {
                if (counter_2 == 3)
                {
                    counter_2 = 0;
                    counter_1++;
                }
                if ((counter_1 == 3 & done1 == false) | (done1 == true & done2 == false & counter_1 != 3))
                {
                    if (done1 == false)
                    {
                        done1 = true;
                        counter_1 = 0;
                        counter_2 = 0;
                    }

                    y2[counter_1, counter_2] = int.Parse(x.Trim());
                    counter_2++;
                }
                else if ((counter_1 == 3 & done1 == true) | (done1 == true & done2 == true))
                {
                    if (done2 == false)
                    {
                        done2 = true;
                        counter_1 = 0;
                        counter_2 = 0;
                    }
                    try { y3[counter_1, counter_2] = int.Parse(x.Trim()); }
                    catch { break; }
                    counter_2++;
                }
                else
                {
                    y1[counter_1, counter_2] = int.Parse(x.Trim());
                    counter_2++;
                }
            }

            //Place blocks
            int playerx = (int)minecraft.Player.Position.Get().X;
            int playery = (int)minecraft.Player.Position.Get().Y;
            int playerz = (int)minecraft.Player.Position.Get().Z;
            int counter = 0;

            while (counter != 3)
            {
                minecraft.World.Block(playerx + 1 + counter, playery, playerz + 1).Set(y1[counter, 0]);
                minecraft.World.Block(playerx + 1 + counter, playery, playerz + 2).Set(y1[counter, 1]);
                minecraft.World.Block(playerx + 1 + counter, playery, playerz + 3).Set(y1[counter, 2]);

                minecraft.World.Block(playerx + 1 + counter, playery + 1, playerz + 1).Set(y2[counter, 0]);
                minecraft.World.Block(playerx + 1 + counter, playery + 1, playerz + 2).Set(y2[counter, 1]);
                minecraft.World.Block(playerx + 1 + counter, playery + 1, playerz + 3).Set(y2[counter, 2]);

                minecraft.World.Block(playerx + 1 + counter, playery + 2, playerz + 1).Set(y3[counter, 0]);
                minecraft.World.Block(playerx + 1 + counter, playery + 2, playerz + 2).Set(y3[counter, 1]);
                minecraft.World.Block(playerx + 1 + counter, playery + 2, playerz + 3).Set(y3[counter, 2]);
                counter++;

            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog();
        }
        

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            int[,] y1 = new int[3, 3];
            int[,] y2 = new int[3, 3];
            int[,] y3 = new int[3, 3];
            int counter = 0;

            //Get blocks
            while (counter != 3)
            {
                y1[counter, 0] = minecraft.World.Block(counter, 57, 0).Id;
                y1[counter, 1] = minecraft.World.Block(counter, 57, 1).Id;
                y1[counter, 2] = minecraft.World.Block(counter, 57, 2).Id;

                y2[counter, 0] = minecraft.World.Block(counter, 58, 0).Id;
                y2[counter, 1] = minecraft.World.Block(counter, 58, 1).Id;
                y2[counter, 2] = minecraft.World.Block(counter, 58, 2).Id;

                y3[counter, 0] = minecraft.World.Block(counter, 59, 0).Id;
                y3[counter, 1] = minecraft.World.Block(counter, 59, 1).Id;
                y3[counter, 2] = minecraft.World.Block(counter, 59, 2).Id;
                counter++;
            }

            //Save block to file
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(saveFileDialog1.FileName))
            {
                //1st layer
                string line1 = y1[0, 0].ToString() + "," + y1[0, 1].ToString() + "," + y1[0, 2].ToString() + ",";
                string line2 = y1[1, 0].ToString() + "," + y1[1, 1].ToString() + "," + y1[1, 2].ToString() + ",";
                string line3 = y1[2, 0].ToString() + "," + y1[2, 1].ToString() + "," + y1[2, 2].ToString() + ",";
                file.WriteLine(line1);
                file.WriteLine(line2);
                file.WriteLine(line3);
                file.WriteLine(" ");

                //2nd layer
                line1 = y2[0, 0].ToString() + "," + y2[0, 1].ToString() + "," + y2[0, 2].ToString() + ",";
                line2 = y2[1, 0].ToString() + "," + y2[1, 1].ToString() + "," + y2[1, 2].ToString() + ",";
                line3 = y2[2, 0].ToString() + "," + y2[2, 1].ToString() + "," + y2[2, 2].ToString() + ",";
                file.WriteLine(line1);
                file.WriteLine(line2);
                file.WriteLine(line3);
                file.WriteLine(" ");

                //3rd layer
                line1 = y3[0, 0].ToString() + "," + y3[0, 1].ToString() + "," + y3[0, 2].ToString() + ",";
                line2 = y3[1, 0].ToString() + "," + y3[1, 1].ToString() + "," + y3[1, 2].ToString() + ",";
                line3 = y3[2, 0].ToString() + "," + y3[2, 1].ToString() + "," + y3[2, 2].ToString() + ",";
                file.WriteLine(line1);
                file.WriteLine(line2);
                file.WriteLine(line3);
            }
        }

        private void buildButton_Click(object sender, EventArgs e)
        {
            //Bottom
            minecraft.World.Block(0, 56, 0).Set(20);
            minecraft.World.Block(1, 56, 0).Set(20);
            minecraft.World.Block(2, 56, 0).Set(20);
            minecraft.World.Block(0, 56, 1).Set(20);
            minecraft.World.Block(0, 56, 2).Set(20);
            minecraft.World.Block(1, 56, 2).Set(20);
            minecraft.World.Block(2, 56, 1).Set(20);
            minecraft.World.Block(1, 56, 1).Set(20);
            minecraft.World.Block(2, 56, 2).Set(20);

            //Pillars
            int counter = 0;
            while (counter != 3)
            {
                minecraft.World.Block(3, 57 + counter, -1).Set(20);
                minecraft.World.Block(3, 57 + counter, 3).Set(20);
                minecraft.World.Block(-1, 57 + counter, -1).Set(20);
                minecraft.World.Block(-1, 57 + counter, 3).Set(20);
                counter++;
            }

            //Air
            counter = 0;
            while (counter != 3)
            {
                minecraft.World.Block(0, 57 + counter, 0).Set(0);
                minecraft.World.Block(1, 57 + counter, 0).Set(0);
                minecraft.World.Block(2, 57 + counter, 0).Set(0);
                minecraft.World.Block(0, 57 + counter, 1).Set(0);
                minecraft.World.Block(0, 57 + counter, 2).Set(0);
                minecraft.World.Block(1, 57 + counter, 2).Set(0);
                minecraft.World.Block(2, 57 + counter, 1).Set(0);
                minecraft.World.Block(1, 57 + counter, 1).Set(0);
                minecraft.World.Block(2, 57 + counter, 2).Set(0);
                counter++;
            }
            //Top
            minecraft.World.Block(0, 60, 0).Set(20);
            minecraft.World.Block(1, 60, 0).Set(20);
            minecraft.World.Block(2, 60, 0).Set(20);
            minecraft.World.Block(0, 60, 1).Set(20);
            minecraft.World.Block(0, 60, 2).Set(20);
            minecraft.World.Block(1, 60, 2).Set(20);
            minecraft.World.Block(2, 60, 1).Set(20);
            minecraft.World.Block(1, 60, 1).Set(20);
            minecraft.World.Block(2, 60, 2).Set(20);

            DialogResult result = MessageBox.Show("Teleport to building box?", "Teleport?",MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                minecraft.Player.Position.Set(1.50, 57.00, 1.50);
            }
            else if (result == DialogResult.No)
            {
                MessageBox.Show("Building box is at 0, 57, 0", Text);
            }
        }

        private void infoButton_Click(object sender, EventArgs e)
        {
            Help help = new Help();
            this.Hide();
            help.ShowDialog();
            this.Show();
        }
    }
}
