﻿namespace Assignment_5_9
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.secondDie = new System.Windows.Forms.PictureBox();
            this.firstDie = new System.Windows.Forms.PictureBox();
            this.rollButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.secondDie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.firstDie)).BeginInit();
            this.SuspendLayout();
            // 
            // secondDie
            // 
            this.secondDie.Image = global::Assignment_5_9.Properties.Resources._6die;
            this.secondDie.Location = new System.Drawing.Point(145, 12);
            this.secondDie.Name = "secondDie";
            this.secondDie.Size = new System.Drawing.Size(100, 100);
            this.secondDie.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.secondDie.TabIndex = 0;
            this.secondDie.TabStop = false;
            // 
            // firstDie
            // 
            this.firstDie.Image = global::Assignment_5_9.Properties.Resources._6die;
            this.firstDie.Location = new System.Drawing.Point(12, 12);
            this.firstDie.Name = "firstDie";
            this.firstDie.Size = new System.Drawing.Size(100, 100);
            this.firstDie.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.firstDie.TabIndex = 1;
            this.firstDie.TabStop = false;
            // 
            // rollButton
            // 
            this.rollButton.Location = new System.Drawing.Point(37, 135);
            this.rollButton.Name = "rollButton";
            this.rollButton.Size = new System.Drawing.Size(75, 23);
            this.rollButton.TabIndex = 2;
            this.rollButton.Text = "R&oll";
            this.rollButton.UseVisualStyleBackColor = true;
            this.rollButton.Click += new System.EventHandler(this.rollButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(145, 135);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(257, 178);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.rollButton);
            this.Controls.Add(this.firstDie);
            this.Controls.Add(this.secondDie);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Dice Roll";
            ((System.ComponentModel.ISupportInitialize)(this.secondDie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.firstDie)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox secondDie;
        private System.Windows.Forms.PictureBox firstDie;
        private System.Windows.Forms.Button rollButton;
        private System.Windows.Forms.Button exitButton;
    }
}

