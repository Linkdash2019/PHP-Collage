﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Threading;

namespace Assignment_5_9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private async void rollButton_Click(object sender, EventArgs e)
        {
            int roll_one;
            int roll_two;
            int steper = 0;
            Random roll = new Random();
            while (steper != 20)
            {
                roll_one = roll.Next(1, 7);
                roll_two = roll.Next(1, 7);

                if (roll_one == 1) { firstDie.Image = Assignment_5_9.Properties.Resources._1die; }
                if (roll_one == 2) { firstDie.Image = Assignment_5_9.Properties.Resources._2die; }
                if (roll_one == 3) { firstDie.Image = Assignment_5_9.Properties.Resources._3die; }
                if (roll_one == 4) { firstDie.Image = Assignment_5_9.Properties.Resources._4die; }
                if (roll_one == 5) { firstDie.Image = Assignment_5_9.Properties.Resources._5die; }
                if (roll_one == 6) { firstDie.Image = Assignment_5_9.Properties.Resources._6die; }

                if (roll_two == 1) { secondDie.Image = Assignment_5_9.Properties.Resources._1die; }
                if (roll_two == 2) { secondDie.Image = Assignment_5_9.Properties.Resources._2die; }
                if (roll_two == 3) { secondDie.Image = Assignment_5_9.Properties.Resources._3die; }
                if (roll_two == 4) { secondDie.Image = Assignment_5_9.Properties.Resources._4die; }
                if (roll_two == 5) { secondDie.Image = Assignment_5_9.Properties.Resources._5die; }
                if (roll_two == 6) { secondDie.Image = Assignment_5_9.Properties.Resources._6die; }

                await Task.Delay(100);
                steper += 1;
            }
        }
    }
}
