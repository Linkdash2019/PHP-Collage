// Cameron McClellan
// Date
// Desc
// Time

import javax.swing.JOptionPane;

public class CameronAssignment00
{
    public static void main(String[] args)
    {
        JOptionPane.showConfirmDialog(null, "Hello World");
    }
}