import javax.swing.*;
import java.awt.*;

public class JFrameTest {
    public static void main(String[] args) {
        // Create a new JFrame (window) with a title
        JFrame frame = new JFrame("My First Window");
        frame.setLayout(new FlowLayout());
        
        // Set the size of the window
        frame.setSize(300, 200);
        
        // Close the program when the window is closed
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Make the window visible
        frame.setVisible(true);
        
        //Put Things in Window
        // Label
        JLabel label = new JLabel("Hello, world!", JLabel.CENTER);
        frame.add(label);
        
        // Button
        JButton button = new JButton("Button!");
        JButton button2 = new JButton("Button2!");
        button2.setPreferredSize(new Dimension(120, 40));
        frame.add(button2);

        
    }
}
//https://copilot.microsoft.com/chats/aXzA2gxNky94Vnwn2b1jr