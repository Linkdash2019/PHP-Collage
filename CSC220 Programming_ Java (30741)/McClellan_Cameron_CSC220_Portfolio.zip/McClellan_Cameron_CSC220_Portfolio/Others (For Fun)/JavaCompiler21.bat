@echo off

REM This batch script was built by MS Copilot Ai I did NOT make it!

REM Drag & drop a Java file onto this batch script to build a JAR

if "%~1"=="" (
    echo Usage: Drag a Java file onto this script, or run:
    echo %~nx0 MyFile.java
    exit /b 1
)

set SRC=%~1

REM Switch to the directory of the source file (fixes UNC path issue)
pushd "%~dp1"

echo Compiling %SRC%...
javac --release 21 "%SRC%"
if errorlevel 1 (
    echo Compilation failed.
    popd
    exit /b 1
)

REM Extract base name (without extension)
for %%f in ("%SRC%") do set BASENAME=%%~nf

REM Create JAR file named after the source file
set JARFILE=%BASENAME%.jar
echo Creating %JARFILE% with main class %BASENAME%...
jar cfe "%JARFILE%" "%BASENAME%" "%BASENAME%.class"

REM Delete CLASS file
del "%BASENAME%.class"
