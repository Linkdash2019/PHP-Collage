public class Test
{
    public static void main(String[] args)
    {
        String name;
        byte biter;
        
        name = "Cameron";
        biter = 15;
        
        System.out.println("Hello World!");
        System.out.println("My name is " + name + "!");
        System.out.println("byte biter is equal to " + biter);
        
        biter += 20;
        
        System.out.println("biter now equals " + biter);
    }
}

//I'm an unhelpful comment