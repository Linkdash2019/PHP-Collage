Name: Cameron McClellan
Course: CSC220 – Programming with Java
Date: 2025 Fall Semester

Desc:
This is all the Java scripts I wrote during CSC220 for my programming certificate. It contains files for every submission (except arrays).
There is also a folder labeled other where I experimented with Java commands not shown in the text book.
We have Assignment 1 where we set up and tested our Java install by printing our names, programming experience, hometown, and hobbies.
Assignment 2 I made a program that calculate the combined cost of stocks and commissions based on user input.
Assignment 3 outputs a receipt based on internal variables ,for price and discount amount, and user input ,for software licenses bought.
Assignment 4 is a simple game where the computer rolls 2 dice. One for you and one for it. The winner has the most points or wins based on user settings.
Assignment 5 we practiced methods by making a configurable ascii robot. Set the size parameters and the program will (hopefully) output a robot. There is not a size error checking so a division can result in a less than 1 situation that causes an infinite loop.
Assignment 6 I made a class that allows you to set a car make and year and the 'car' class would remember for later. This was a late assignment as I was transferring to using NetBeans Ide.
Assignment 7 was meant to be arrays but I do not have a program for that.
Assignment 8 we worked on classes again. This time I made a program that allows for a 'month' variable that can be any valid month. It then can output an integer (1-12) or a month (Jan-Dec).
Assignment 9 contains a disk player simulator. It uses inheritance to add extensions to the base class MediaCollection. Each 'Disk' is an object made during runtime.
Others contains little experiments or program templates. I found out I could run JRE on my iPhone which led to experiments with JFrame. Assigment00 is a Java template I made and used before I switched to using NetBeans.

Overall I am the most proud of Assignment 4. That's when I realized I really enjoy Java and I put a lot of effort into the code after misunderstanding inscruptions multiple times until it felt right.
Assignment 6 was the hardest just because classes made no sense until I got an actual development IDE setup to assist with class making.
For three Java concepts I feel I really grasped. Methods, Data Types, and the jOptionPane.